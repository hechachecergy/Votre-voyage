.claude/CLAUDE.md
