# MCP Dashboard

A local web dashboard that reads your `claude_desktop_config.json`, probes server
liveness, and displays all MCP servers grouped by category with live refresh.

## Quick start

```bash
cd mcp-dashboard
npm install
npm start
# open http://localhost:3333
```

For auto-reload during development:
```bash
npm run dev
```

To use a different port:
```bash
PORT=4000 npm start
```

## How it works

### Config discovery
The backend searches for your Claude config file in order:

| Platform | Path |
|----------|------|
| macOS    | `~/Library/Application Support/Claude/claude_desktop_config.json` |
| Linux    | `~/.config/claude/claude_desktop_config.json` |
| Windows  | `%APPDATA%\Claude\claude_desktop_config.json` |
| Override | `MCP_CONFIG_PATH=/path/to/config.json npm start` |

### Liveness probes
- **HTTP/SSE servers** (those with a `url` field): sends a `HEAD` request, 2.5s timeout.
- **Stdio servers** (those with `command` + `args`): checks if the binary exists on `PATH`
  or as an absolute path on disk. No process is spawned.

Status meanings:
- 🟢 **active** — probe succeeded
- 🔴 **inactive** — probe failed / binary not found
- 🟡 **unknown** — no command or URL to probe against

### Category heuristics
Servers are categorized by matching their key, command, args, and env var names
against keyword lists. Categories (in match priority):

`database` → `devtools` → `storage` → `comms` → `crm` → `analytics` → `monitoring` → `automation` → `geo` → `misc`

### API endpoints

| Endpoint | Description |
|----------|-------------|
| `GET /api/servers` | All servers, probed and categorized |
| `GET /api/servers/:key/probe` | Re-probe a single server |
| `GET /api/categories` | Static category list |
| `GET /api/config` | Raw config file (for debugging) |

## Extending

**Add a new category** — edit `CATEGORY_RULES` in `server/index.js`:
```js
{ id: "mycat", label: "My category", icon: "🔧", keywords: ["mytool", "myservice"] },
```

**Override config path at runtime:**
```bash
MCP_CONFIG_PATH=/custom/path/config.json npm start
```

**Custom probe logic** — extend the `probe()` function in `server/index.js` to add
health-check endpoints, process inspection, or socket probes.
