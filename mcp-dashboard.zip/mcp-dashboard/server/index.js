/**
 * MCP Dashboard — Backend
 * Reads claude_desktop_config.json, categorizes servers, probes liveness.
 *
 * Start with:  node server/index.js
 * Or:          PORT=4000 node server/index.js
 */

const express = require("express");
const fs      = require("fs");
const path    = require("path");
const http    = require("http");
const https   = require("https");
const { execSync } = require("child_process");

const app  = express();
const PORT = process.env.PORT || 3333;

// ─── Config file locations (searched in order) ───────────────────────────────
const CONFIG_CANDIDATES = [
  // macOS
  path.join(process.env.HOME || "", "Library/Application Support/Claude/claude_desktop_config.json"),
  // Linux / WSL
  path.join(process.env.HOME || "", ".config/claude/claude_desktop_config.json"),
  // Windows
  path.join(process.env.APPDATA || "", "Claude/claude_desktop_config.json"),
  // Env override
  process.env.MCP_CONFIG_PATH || "",
].filter(Boolean);

// ─── Category heuristics ─────────────────────────────────────────────────────
const CATEGORY_RULES = [
  { id: "database",   label: "Database",      icon: "🗄",  keywords: ["postgres","mysql","sqlite","supabase","mongo","redis","neon","planetscale","turso","db","sql","database"] },
  { id: "devtools",   label: "Devtools & APIs",icon: "⚙",  keywords: ["github","git","gitlab","bitbucket","jira","linear","notion","apollo","graphql","graphos","vercel","netlify","railway","fly"] },
  { id: "storage",    label: "Storage & files",icon: "📁", keywords: ["drive","s3","gcs","blob","storage","dropbox","onedrive","box","file"] },
  { id: "comms",      label: "Communications", icon: "✉",  keywords: ["gmail","mail","calendar","slack","discord","teams","twilio","sendgrid","resend","chat","message"] },
  { id: "crm",        label: "CRM & sales",    icon: "🤝", keywords: ["crm","close","zoho","salesforce","hubspot","lead","contact","desk","ticket","pipedrive"] },
  { id: "analytics",  label: "Analytics & BI", icon: "📊", keywords: ["analytics","metabase","databricks","snowflake","bigquery","redshift","dbt","looker","tableau","finance","invoice","billing","books","stripe"] },
  { id: "monitoring", label: "Monitoring",     icon: "📡", keywords: ["sentry","datadog","newrelic","pagerduty","prometheus","grafana","honeybadger","rollbar","logrocket","bugsnag","log","monitor","alert"] },
  { id: "automation", label: "Automation",     icon: "⚡", keywords: ["playwright","puppeteer","selenium","zapier","n8n","make","pipedream","ci","cd","github-actions","jenkins","airflow","cron","script","worker","queue","task","project"] },
  { id: "geo",        label: "Geo & location", icon: "🗺", keywords: ["maps","places","geocode","weather","geo","location","directions"] },
  { id: "misc",       label: "Misc / other",   icon: "◼",  keywords: [] },
];

function categorize(key, cfg) {
  const haystack = [
    key,
    cfg.command || "",
    (cfg.args || []).join(" "),
    (cfg.env ? Object.keys(cfg.env).join(" ") : ""),
  ].join(" ").toLowerCase();

  for (const rule of CATEGORY_RULES) {
    if (rule.id === "misc") continue;
    if (rule.keywords.some(k => haystack.includes(k))) return rule.id;
  }
  return "misc";
}

// ─── Config reader ────────────────────────────────────────────────────────────
function readConfig() {
  for (const p of CONFIG_CANDIDATES) {
    try {
      const raw = fs.readFileSync(p, "utf8");
      const parsed = JSON.parse(raw);
      return { path: p, mcpServers: parsed.mcpServers || {} };
    } catch (_) { /* try next */ }
  }
  return { path: null, mcpServers: {} };
}

// ─── Liveness probe ───────────────────────────────────────────────────────────
// For HTTP/HTTPS servers we do a HEAD request.
// For stdio servers we check if the binary/script exists on disk.
function probe(key, cfg) {
  return new Promise(resolve => {
    const timeout = setTimeout(() => resolve({ status: "unknown", latency: null }), 3000);

    // HTTP/SSE transport
    if (cfg.url) {
      const url = cfg.url;
      const lib = url.startsWith("https") ? https : http;
      const start = Date.now();
      try {
        const req = lib.request(url, { method: "HEAD", timeout: 2500 }, res => {
          clearTimeout(timeout);
          resolve({
            status: res.statusCode < 500 ? "active" : "inactive",
            latency: Date.now() - start,
            httpStatus: res.statusCode,
          });
        });
        req.on("error", () => { clearTimeout(timeout); resolve({ status: "inactive", latency: null }); });
        req.end();
      } catch (_) {
        clearTimeout(timeout);
        resolve({ status: "inactive", latency: null });
      }
      return;
    }

    // Stdio transport — check binary exists
    const cmd = cfg.command;
    if (!cmd) { clearTimeout(timeout); resolve({ status: "unknown", latency: null }); return; }

    try {
      // For npx / node / python etc., check the command is on PATH
      execSync(`command -v ${cmd.split("/").pop()}`, { stdio: "ignore", timeout: 1000 });
      clearTimeout(timeout);
      resolve({ status: "active", latency: null });
    } catch (_) {
      // Fallback: check if it's an absolute/relative path that exists
      const exists = fs.existsSync(cmd) || fs.existsSync(path.resolve(cmd));
      clearTimeout(timeout);
      resolve({ status: exists ? "active" : "inactive", latency: null });
    }
  });
}

// ─── Routes ───────────────────────────────────────────────────────────────────
app.use(express.static(path.join(__dirname, "../public")));
app.use((_, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  next();
});

// GET /api/categories — static list
app.get("/api/categories", (_, res) => res.json(CATEGORY_RULES));

// GET /api/servers — parse config, probe all, return enriched list
app.get("/api/servers", async (_, res) => {
  const { path: configPath, mcpServers } = readConfig();
  const entries = Object.entries(mcpServers);

  const results = await Promise.all(
    entries.map(async ([key, cfg]) => {
      const { status, latency, httpStatus } = await probe(key, cfg);
      return {
        key,
        name: key
          .replace(/[-_]/g, " ")
          .replace(/\b\w/g, c => c.toUpperCase()),
        command: cfg.command
          ? [cfg.command, ...(cfg.args || [])].join(" ").slice(0, 80)
          : cfg.url || "—",
        url: cfg.url || null,
        env: cfg.env ? Object.keys(cfg.env) : [],
        args: cfg.args || [],
        category: categorize(key, cfg),
        status,
        latency,
        httpStatus: httpStatus || null,
        checkedAt: new Date().toISOString(),
        rawConfig: cfg,
      };
    })
  );

  res.json({
    configPath,
    serverCount: results.length,
    checkedAt: new Date().toISOString(),
    servers: results,
  });
});

// GET /api/servers/:key/probe — re-probe a single server
app.get("/api/servers/:key/probe", async (req, res) => {
  const { mcpServers } = readConfig();
  const cfg = mcpServers[req.params.key];
  if (!cfg) return res.status(404).json({ error: "Server not found" });
  const result = await probe(req.params.key, cfg);
  res.json({ key: req.params.key, ...result, checkedAt: new Date().toISOString() });
});

// GET /api/config — raw config file contents (for debugging)
app.get("/api/config", (_, res) => {
  const { path: configPath, mcpServers } = readConfig();
  if (!configPath) return res.status(404).json({ error: "No config file found", searched: CONFIG_CANDIDATES });
  res.json({ configPath, mcpServers });
});

app.listen(PORT, () => {
  console.log(`\n  MCP Dashboard running at http://localhost:${PORT}`);
  console.log(`  Config candidates searched:`);
  CONFIG_CANDIDATES.forEach(p => console.log(`    ${p}`));
  console.log();
});
