# Modèles de séances TOEIC (B1–C1)

Ce document présente 6 séances types prêtes à l'emploi pour les enseignants préparant leurs étudiants au TOEIC. Chaque séance est détaillée avec objectifs, déroulé, timing, et rôle de l'agent TOEIC Coach.

---

## SÉANCE 1 : Diagnostic & Définition des Objectifs

**Niveau visé** : B1–C1 (tous niveaux)  
**Objectif pédagogique** : Évaluer le niveau initial des étudiants, identifier les points forts et faibles, définir des objectifs individuels, présenter l'agent TOEIC Coach  
**Durée totale** : 90 minutes  
**Matériel nécessaire** : Ordinateurs avec accès à l'agent, écouteurs, feuilles de réponse, tableau blanc

---

### Déroulé de la séance

| **Timing** | **Activité** | **Description** | **Rôle de l'agent TOEIC Coach** | **Rôle du professeur** |
|------------|--------------|-----------------|--------------------------------|------------------------|
| **0-10 min** | Introduction et présentation | Présentation du TOEIC (format, échelle de scores, objectifs professionnels), présentation de l'agent TOEIC Coach comme outil complémentaire | Aucun (professeur présente l'agent) | Introduit le TOEIC, explique l'importance du score, présente l'outil numérique |
| **10-50 min** | Test de positionnement | Les étudiants passent un mini-test de 30 questions (15 Listening + 15 Reading) via l'agent. Conditions d'examen (silence, chronomètre) | Génère le mini-test de 30 questions adaptées, chronomètre, collecte les réponses | Supervise le bon déroulement, assure le silence, aide en cas de problème technique |
| **50-60 min** | Correction automatique | L'agent corrige immédiatement le test et fournit à chaque étudiant un score estimé + rapport de diagnostic (points forts/faibles) | Corrige automatiquement, calcule le score estimé, génère un rapport individuel | Circule dans la salle, aide à la lecture des rapports |
| **60-75 min** | Analyse collective | Debriefing collectif : format du test, types de questions, stratégies de base pour chaque partie. Le professeur commente les résultats généraux (sans nommer les étudiants) | Aucun (phase collective animée par le professeur) | Explique le format TOEIC, donne les premières stratégies, rassure sur les résultats initiaux |
| **75-85 min** | Définition des objectifs individuels | Chaque étudiant note son score actuel et définit son score cible (selon exigences du diplôme). Interaction avec l'agent pour obtenir un plan de révision personnalisé de 8-12 semaines | Propose un plan de révision initial basé sur score actuel, score cible, et temps disponible | Aide les étudiants à fixer des objectifs réalistes, encourage, motive |
| **85-90 min** | Consignes pour le travail autonome | Le professeur explique comment utiliser l'agent entre les séances : fréquence recommandée (3-5h/semaine), types d'exercices à faire, suivi dans le tableur | Aucun | Donne les consignes d'usage de l'agent, distribue le lien d'accès et les identifiants |

---

### Livrables de la séance

- **Pour chaque étudiant** : Score estimé initial, rapport de diagnostic (points forts/faibles), objectif de score cible, plan de révision personnalisé
- **Pour le professeur** : Tableau récapitulatif des niveaux de la classe (à reporter dans le tableur de suivi)

### Conseils pédagogiques

- Rassurez les étudiants : le score initial n'est qu'un point de départ, la progression est toujours possible
- Insistez sur la régularité : 30 minutes par jour valent mieux que 3h une fois par semaine
- Montrez l'interface de l'agent en vidéoprojection pour faciliter la prise en main

---

## SÉANCE 2 : Part 5 – Grammaire et Vocabulaire

**Niveau visé** : B1–B2 (débutant et intermédiaire)  
**Objectif pédagogique** : Maîtriser la Part 5 (Incomplete Sentences) en se concentrant sur les temps verbaux, prépositions, et vocabulaire courant  
**Durée totale** : 90 minutes  
**Matériel nécessaire** : Ordinateurs avec accès à l'agent, polycopiés de règles grammaticales, tableau blanc

---

### Déroulé de la séance

| **Timing** | **Activité** | **Description** | **Rôle de l'agent TOEIC Coach** | **Rôle du professeur** |
|------------|--------------|-----------------|--------------------------------|------------------------|
| **0-10 min** | Rappel théorique | Révision rapide des temps verbaux (présent, passé, futur, present perfect) et des prépositions courantes (in, on, at, for, since, during) | Aucun | Explique les règles grammaticales clés pour Part 5 au tableau |
| **10-30 min** | Exercices guidés (grammaire) | Les étudiants demandent à l'agent 15 questions Part 5 focalisées sur les temps verbaux. Correction immédiate après chaque question avec explication en français | Génère 15 questions Part 5 (grammaire), fournit la correction et l'explication détaillée en français | Circule, aide les étudiants qui bloquent, clarifie les explications de l'agent si nécessaire |
| **30-40 min** | Mise en commun | Le professeur sélectionne 3-4 questions difficiles et les projette. Discussion collective : pourquoi cette réponse, quel piège, quelle stratégie pour aller vite | Aucun (sauf si besoin de régénérer une question similaire pour exemple) | Anime la discussion, explique les pièges courants (distracteurs), donne des techniques de repérage rapide |
| **40-60 min** | Exercices guidés (vocabulaire) | Les étudiants demandent à l'agent 15 questions Part 5 focalisées sur le vocabulaire professionnel (choix du mot approprié, synonymes). Correction immédiate | Génère 15 questions Part 5 (vocabulaire), fournit explications des nuances de vocabulaire en français | Circule, note les mots inconnus récurrents, prépare une liste de vocabulaire à distribuer |
| **60-70 min** | Mise en commun (vocabulaire) | Le professeur projette 3-4 questions de vocabulaire difficiles. Explication des collocations (mots qui vont ensemble), contextes d'usage | Aucun | Explique les différences entre synonymes, donne des exemples de collocations, propose des moyens mnémotechniques |
| **70-85 min** | Mini-test chronométré | Mini-test Part 5 : 30 questions en 12 minutes (temps recommandé officiel : 10-12 min). L'agent génère le test et chronomètre | Génère 30 questions Part 5 mixtes (grammaire + vocabulaire), chronomètre 12 minutes, corrige automatiquement | Supervise le timing, assure le silence, note les étudiants qui finissent trop tôt ou trop tard |
| **85-90 min** | Debrief et consignes | Correction rapide du mini-test (score sur 30), identification des erreurs persistantes. Consignes pour le travail autonome : faire 20 questions Part 5 par jour pendant 1 semaine via l'agent | Fournit le score et la correction du mini-test | Encourage, donne les consignes de travail autonome, rappelle l'objectif (automatiser les réponses Part 5) |

---

### Livrables de la séance

- **Pour chaque étudiant** : Score au mini-test Part 5, liste des 10-15 mots de vocabulaire clés à apprendre
- **Pour le professeur** : Identification des difficultés grammaticales récurrentes dans la classe

### Conseils pédagogiques

- Part 5 est la partie la plus "automatisable" du TOEIC : insistez sur la répétition et la vitesse
- Encouragez les étudiants à créer des fiches de révision (temps verbaux, prépositions, vocabulaire thématique)
- Montrez qu'une bonne maîtrise de Part 5 fait gagner du temps pour Part 7 (lecture)

---

## SÉANCE 3 : Part 6 – Textes à Compléter

**Niveau visé** : B1–B2 (débutant et intermédiaire)  
**Objectif pédagogique** : Maîtriser la Part 6 (Text Completion) en développant la compréhension du contexte et la cohérence textuelle  
**Durée totale** : 90 minutes  
**Matériel nécessaire** : Ordinateurs avec accès à l'agent, polycopiés d'exemples de textes, tableau blanc

---

### Déroulé de la séance

| **Timing** | **Activité** | **Description** | **Rôle de l'agent TOEIC Coach** | **Rôle du professeur** |
|------------|--------------|-----------------|--------------------------------|------------------------|
| **0-15 min** | Présentation de Part 6 | Explication du format : 4 textes avec 4 blancs chacun (total 16 questions). Types de questions : grammaire, vocabulaire, insertion de phrase complète. Importance du contexte | Aucun | Explique le format Part 6, montre un exemple au tableau, insiste sur la nécessité de lire tout le texte (pas seulement la phrase avec le blanc) |
| **15-40 min** | Exercice guidé (2 textes) | Les étudiants demandent à l'agent 2 textes Part 6 (8 questions total). Consigne : lire d'abord le texte entier, puis répondre aux 4 questions. Correction immédiate après chaque texte | Génère 2 textes Part 6 avec 4 questions chacun (grammaire, vocabulaire, insertion de phrase), corrige avec explications en français | Circule, observe les stratégies de lecture, aide ceux qui répondent trop vite sans lire le contexte |
| **40-55 min** | Analyse collective | Le professeur projette 1 texte Part 6 complet. Lecture collective à voix haute (volontaire). Discussion : indices de contexte, choix des réponses, pièges (mots qui semblent corrects hors contexte mais pas dans le texte) | Aucun | Anime la lecture collective, souligne les indices contextuels (connecteurs logiques, cohérence temporelle, thématique), explique les pièges |
| **55-75 min** | Exercice autonome (2 textes) | Les étudiants demandent à l'agent 2 nouveaux textes Part 6 (8 questions). Travail individuel, correction automatique après chaque texte | Génère 2 textes Part 6, corrige automatiquement avec feedback détaillé | Circule, note les étudiants en difficulté, offre un soutien individuel |
| **75-85 min** | Mini-test chronométré | Mini-test Part 6 complet : 4 textes, 16 questions en 10 minutes (temps recommandé officiel : 8-10 min). L'agent génère et chronomètre | Génère 4 textes Part 6 (16 questions), chronomètre 10 minutes, corrige automatiquement | Supervise le timing, observe la gestion du temps (certains étudiants passent trop de temps par texte) |
| **85-90 min** | Debrief et consignes | Correction du mini-test (score sur 16), discussion des difficultés. Consignes pour le travail autonome : faire 2 textes Part 6 par jour pendant 1 semaine via l'agent, en chronométrant (objectif : 2-3 min par texte) | Fournit le score et la correction du mini-test | Encourage, insiste sur la stratégie de lecture rapide mais complète du texte, donne les consignes de travail autonome |

---

### Livrables de la séance

- **Pour chaque étudiant** : Score au mini-test Part 6, liste des connecteurs logiques et mots de transition clés
- **Pour le professeur** : Identification des étudiants qui lisent trop vite (et se trompent) vs trop lentement

### Conseils pédagogiques

- Part 6 teste la compréhension globale d'un texte court : insistez sur la lecture du contexte avant de répondre
- Montrez que l'insertion de phrase complète (1 question sur 4) nécessite de comprendre la logique du paragraphe
- Encouragez les étudiants à repérer les connecteurs logiques (however, therefore, in addition, for example)

---

## SÉANCE 4 : Part 7 – Compréhension Écrite (Passages Simples)

**Niveau visé** : B2–C1 (intermédiaire et avancé)  
**Objectif pédagogique** : Développer les techniques de lecture rapide et la compréhension de documents professionnels (emails, annonces, articles)  
**Durée totale** : 90 minutes  
**Matériel nécessaire** : Ordinateurs avec accès à l'agent, polycopiés d'exemples de documents, tableau blanc

---

### Déroulé de la séance

| **Timing** | **Activité** | **Description** | **Rôle de l'agent TOEIC Coach** | **Rôle du professeur** |
|------------|--------------|-----------------|--------------------------------|------------------------|
| **0-10 min** | Présentation de Part 7 (passages simples) | Explication du format : 10 documents simples (emails, publicités, annonces, articles) avec 2-4 questions chacun (total 29 questions). Types de questions : idée principale, détails, inférences, vocabulaire en contexte | Aucun | Explique le format Part 7, montre la différence entre passages simples et multiples, introduit les techniques de scanning (chercher une info précise) et skimming (lecture rapide pour l'idée générale) |
| **10-35 min** | Exercice guidé (3 passages) | Les étudiants demandent à l'agent 3 passages simples Part 7 (6-9 questions). Consigne : lire d'abord les questions, puis lire le texte en cherchant les réponses (technique de scanning). Correction après chaque passage | Génère 3 passages simples Part 7 (email professionnel, annonce, article), avec 2-3 questions chacun, corrige avec explications | Circule, observe les techniques de lecture, conseille ceux qui lisent trop lentement (mot à mot) ou trop vite (et ratent des détails) |
| **35-50 min** | Analyse collective (technique de scanning) | Le professeur projette 1 passage Part 7 + 3 questions. Démonstration : lire les questions en premier, identifier les mots-clés, scanner le texte pour trouver les infos, répondre rapidement | Aucun | Démontre la technique de scanning (chercher un nom, une date, un chiffre), explique comment éliminer les réponses distractrices, montre l'importance des mots-clés |
| **50-70 min** | Exercice autonome (5 passages) | Les étudiants demandent à l'agent 5 passages simples Part 7 (10-15 questions). Travail individuel avec chronomètre : 3-4 minutes maximum par passage. Correction automatique | Génère 5 passages simples Part 7, chronomètre, corrige automatiquement avec feedback | Circule, aide les étudiants en difficulté, note ceux qui prennent trop de temps (signe de lecture inefficace) |
| **70-85 min** | Mini-test chronométré | Mini-test Part 7 (passages simples uniquement) : 6 passages, 15 questions en 20 minutes. L'agent génère et chronomètre | Génère 6 passages simples Part 7 (15 questions), chronomètre 20 minutes, corrige automatiquement | Supervise le timing, observe la stratégie de lecture (certains lisent dans l'ordre, d'autres commencent par les questions courtes) |
| **85-90 min** | Debrief et consignes | Correction du mini-test (score sur 15), discussion : quels types de passages sont les plus difficiles (emails, articles, annonces), quels types de questions posent problème (inférences, vocabulaire). Consignes de travail autonome : faire 3 passages Part 7 par jour via l'agent | Fournit le score et la correction du mini-test | Encourage, insiste sur la régularité et la lecture en anglais (journaux, blogs) pour améliorer la vitesse, donne les consignes de travail autonome |

---

### Livrables de la séance

- **Pour chaque étudiant** : Score au mini-test Part 7 (passages simples), liste des types de documents TOEIC courants (email, annonce, article, notice)
- **Pour le professeur** : Identification des types de passages qui posent le plus de problèmes à la classe

### Conseils pédagogiques

- Part 7 est la partie la plus longue (54 questions) : la gestion du temps est critique
- Insistez sur la technique de lecture des questions AVANT le texte (gain de temps, lecture ciblée)
- Encouragez la pratique quotidienne de la lecture en anglais (même 10 minutes) pour améliorer la vitesse

---

## SÉANCE 5 : Listening (Parts 3-4 – Dialogues et Monologues)

**Niveau visé** : B1–C1 (tous niveaux, avec adaptation de la difficulté)  
**Objectif pédagogique** : Améliorer la compréhension orale de dialogues (Part 3) et de monologues (Part 4), développer l'écoute active et la prise de notes  
**Durée totale** : 90 minutes  
**Matériel nécessaire** : Ordinateurs avec écouteurs, accès à l'agent, tableau blanc, feuilles de brouillon pour prise de notes

---

### Déroulé de la séance

| **Timing** | **Activité** | **Description** | **Rôle de l'agent TOEIC Coach** | **Rôle du professeur** |
|------------|--------------|-----------------|--------------------------------|------------------------|
| **0-10 min** | Présentation Parts 3 et 4 | Explication du format : Part 3 = conversations entre 2-3 personnes (39 questions, 3 par dialogue), Part 4 = monologues (30 questions, 3 par talk). Importance de l'écoute active et de la prise de notes (noms, chiffres, lieux) | Aucun | Explique le format Listening Parts 3-4, donne des conseils d'écoute (repérer les indices sonores, intonations, mots-clés), montre un exemple de prise de notes efficace |
| **10-30 min** | Exercice guidé Part 3 (3 dialogues) | Les étudiants demandent à l'agent 3 dialogues Part 3 (9 questions). Consigne : lire les questions avant d'écouter, prendre des notes pendant l'écoute, répondre. Correction après chaque dialogue avec transcription | Génère 3 dialogues Part 3 (contextes variés : bureau, magasin, téléphone) avec 3 questions chacun, fournit transcription après réponse, explique les réponses en français | Circule, observe les techniques d'écoute, aide ceux qui paniquent ou qui n'arrivent pas à suivre le rythme |
| **30-45 min** | Analyse collective (Part 3) | Le professeur projette la transcription d'un dialogue difficile. Écoute collective (si audio disponible) ou lecture de la transcription. Discussion : quels indices ont permis de trouver les réponses, quels mots-clés, quels pièges dans les distracteurs | Fournit la transcription d'un dialogue | Anime l'écoute collective, souligne les mots-clés et les indices contextuels (qui parle, intentions, détails), explique les pièges des réponses distractrices |
| **45-65 min** | Exercice guidé Part 4 (3 monologues) | Les étudiants demandent à l'agent 3 monologues Part 4 (9 questions). Types : annonces (aéroport, magasin), instructions, messages vocaux. Consigne : lire les questions avant, prendre des notes (chiffres, dates, lieux), répondre. Correction avec transcription | Génère 3 monologues Part 4 (annonces, publicités, instructions) avec 3 questions chacun, fournit transcription, explique en français | Circule, aide ceux qui se perdent dans les monologues longs, conseille sur la prise de notes (abréviations, symboles) |
| **65-80 min** | Mini-test chronométré (Listening Parts 3-4) | Mini-test Listening : 2 dialogues Part 3 (6 questions) + 2 monologues Part 4 (6 questions), soit 12 questions en 10-12 minutes. L'agent génère et joue les audios (simulation) | Génère 2 dialogues Part 3 + 2 monologues Part 4 (12 questions), simule l'écoute (l'étudiant lit les transcriptions ou imagine l'audio), corrige automatiquement | Supervise, chronomètre, observe la concentration des étudiants |
| **80-90 min** | Debrief et consignes | Correction du mini-test (score sur 12), discussion : quelles parties sont les plus difficiles (conversations rapides, accents, monologues techniques). Consignes pour le travail autonome : écouter des podcasts en anglais, séries, films en VO, utiliser l'agent pour s'entraîner sur Parts 3-4 (2-3 dialogues/talks par jour) | Fournit le score et la correction du mini-test | Encourage, recommande des ressources d'écoute (podcasts business, TED Talks, séries), donne les consignes de travail autonome |

---

### Livrables de la séance

- **Pour chaque étudiant** : Score au mini-test Listening Parts 3-4, fiche de techniques de prise de notes (abréviations, symboles)
- **Pour le professeur** : Identification des difficultés d'écoute (vitesse, accents, vocabulaire spécialisé)

### Conseils pédagogiques

- La compréhension orale s'améliore avec la pratique régulière : encouragez l'écoute quotidienne en anglais (10-15 min)
- Insistez sur la technique de lecture des questions AVANT l'écoute (permet d'anticiper et de cibler l'attention)
- Rassurez les étudiants : il n'est pas nécessaire de comprendre chaque mot, seulement les idées principales et les détails clés

---

## SÉANCE 6 : Mini-Simulation d'Examen et Débrief

**Niveau visé** : B1–C1 (tous niveaux)  
**Objectif pédagogique** : Simuler un examen TOEIC en conditions réelles (version raccourcie), évaluer la progression, identifier les dernières lacunes, préparer psychologiquement au jour J  
**Durée totale** : 90 minutes (+ possibilité de prolonger à 2h pour simulation complète)  
**Matériel nécessaire** : Ordinateurs avec écouteurs, accès à l'agent, feuilles de réponse, chronomètres, salle au calme

---

### Déroulé de la séance (version 90 minutes = test partiel 100 questions)

| **Timing** | **Activité** | **Description** | **Rôle de l'agent TOEIC Coach** | **Rôle du professeur** |
|------------|--------------|-----------------|--------------------------------|------------------------|
| **0-5 min** | Instructions et installation | Le professeur donne les consignes d'examen (silence, pas de communication, gestion du temps). Les étudiants s'installent avec écouteurs, ouvrent l'accès à l'agent, se préparent mentalement | Aucun | Donne les consignes, rassure, lance le test |
| **5-30 min** | Listening (50 questions) | Simulation Listening : 50 questions (proportions respectées : 3 Part 1, 12 Part 2, 19 Part 3, 16 Part 4). Les étudiants écoutent (via l'agent ou audio simulé) et répondent sur la feuille ou directement dans l'interface | Génère 50 questions Listening respectant les proportions, simule l'écoute (si audio disponible ou consigne de lecture des transcriptions comme si elles étaient entendues) | Supervise le silence, chronomètre 25 minutes, observe la concentration |
| **30-68 min** | Reading (50 questions) | Simulation Reading : 50 questions (proportions respectées : 15 Part 5, 8 Part 6, 27 Part 7). Les étudiants lisent et répondent. Temps : 38 minutes (proportionnel au test complet de 75 min) | Génère 50 questions Reading respectant les proportions | Supervise, chronomètre 38 minutes, observe la gestion du temps (qui finit trop tôt, qui est en retard) |
| **68-73 min** | Correction automatique | L'agent corrige immédiatement le test et fournit à chaque étudiant son score estimé (Listening, Reading, Total sur 990), ainsi qu'un rapport de performance par partie | Corrige automatiquement les 100 réponses, calcule le score estimé, génère un rapport détaillé (% de réussite par partie, points forts/faibles) | Pause pour le professeur, préparation du débrief |
| **73-85 min** | Débrief individuel assisté | Chaque étudiant consulte son rapport de performance généré par l'agent. Il identifie ses 2-3 priorités d'amélioration. Le professeur circule pour donner des conseils personnalisés | Fournit le rapport détaillé, propose des recommandations d'entraînement ciblé pour les 2 prochaines semaines | Circule, donne des conseils individuels, encourage, rassure ceux dont le score a baissé, félicite les progressions |
| **85-90 min** | Débrief collectif et conseils finaux | Discussion collective : impressions générales, difficultés rencontrées, gestion du temps, stress. Le professeur donne les derniers conseils pour le vrai examen (matériel, stratégies, confiance). Consignes pour les dernières semaines | Aucun | Anime la discussion, donne les stratégies finales (guessing intelligent, gestion du stress, sommeil, alimentation avant l'examen), motive pour le sprint final |

---

### Déroulé alternatif (2h = simulation complète 200 questions)

Si vous disposez de 2 heures complètes :

- **0-5 min** : Instructions
- **5-50 min** : Listening complet (100 questions, 45 min)
- **50-125 min** : Reading complet (100 questions, 75 min)
- **125-130 min** : Correction automatique (agent)
- **130-150 min** : Débrief individuel assisté + débrief collectif (20 min)

---

### Livrables de la séance

- **Pour chaque étudiant** : Score estimé au test partiel ou complet, rapport de performance détaillé par partie, plan d'action pour les 2 dernières semaines
- **Pour le professeur** : Tableau de synthèse des scores de la classe, identification des étudiants en difficulté nécessitant un soutien supplémentaire

### Conseils pédagogiques

- La simulation est un moment clé : reproduisez au maximum les conditions d'examen (silence, chronomètre, stress positif)
- Insistez sur le fait que le score de simulation n'est pas le score final : il reste du temps pour progresser
- Utilisez le débrief pour remotiver les étudiants et ajuster les plans de révision individuels
- Proposez une simulation complète (200 questions) au moins 1 fois avant l'examen réel (idéalement 2-3 semaines avant)

---

## NOTES GÉNÉRALES POUR L'UTILISATION DES SÉANCES

### Adaptation au niveau de la classe

- **Classe homogène B1** : Privilégiez les séances 1, 2, 3, 5 (bases grammaticales et vocabulaire)
- **Classe homogène B2** : Séances 2, 3, 4, 5, 6 (entraînement complet avec focus stratégies)
- **Classe homogène C1** : Séances 4, 5, 6 + exercices avancés générés par l'agent (passages multiples complexes, vocabulaire business)
- **Classe hétérogène (B1-C1)** : Utilisez la différenciation via l'agent (chaque étudiant demande des exercices adaptés à son niveau pendant les phases d'exercice autonome)

### Fréquence recommandée

- **Formation intensive (4 semaines)** : 2-3 séances par semaine (6-9h de cours) + 10h de travail autonome avec l'agent
- **Formation standard (8-12 semaines)** : 1-2 séances par semaine (2-4h de cours) + 3-5h de travail autonome avec l'agent

### Suivi entre les séances

- **Demandez aux étudiants** de noter leurs scores et leur temps de travail autonome dans le tableur de suivi
- **Vérifiez chaque semaine** que les étudiants utilisent bien l'agent (au moins 3h/semaine recommandées)
- **Identifiez rapidement** les étudiants qui décrochent ou qui stagnent, et ajustez leur plan

### Encouragement et motivation

- **Célébrez les progrès** : même +20 points entre deux tests est une victoire
- **Rassurez** : le TOEIC se travaille, les stratégies s'apprennent, la progression est toujours possible
- **Fixez des micro-objectifs** : +50 points par mois, ou +10 points par semaine
- **Variez les formats** : alternez séances en classe et travail autonome pour éviter la lassitude

---

**Ces 6 séances types constituent un socle pédagogique solide pour préparer vos étudiants au TOEIC avec l'agent TOEIC Coach. Adaptez-les selon vos contraintes et votre public. Bonne préparation !**
