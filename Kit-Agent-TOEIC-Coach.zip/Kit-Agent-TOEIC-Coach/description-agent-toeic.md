# Description de l'agent TOEIC Coach

## 1. Rôle principal de l'agent

L'**agent TOEIC Coach** est un assistant pédagogique intelligent conçu pour accompagner les étudiants et les enseignants dans la préparation au test TOEIC (Test of English for International Communication). Il agit comme un coach personnel disponible 24h/24, capable de :

- Évaluer le niveau actuel de l'étudiant
- Générer des exercices adaptés à chaque partie du TOEIC
- Proposer des parcours de révision personnalisés
- Fournir des feedbacks détaillés et constructifs en français
- Simuler des conditions d'examen réalistes
- Suivre la progression dans le temps

L'agent combine l'intelligence artificielle avec une expertise pédagogique approfondie du format TOEIC, offrant un entraînement ciblé, structuré et motivant.

---

## 2. Public cible

### Profil des apprenants

L'agent TOEIC Coach s'adresse principalement aux **étudiants de niveau B1 à C1** (intermédiaire à avancé) inscrits dans :

- **Écoles de commerce et de management** (Bachelor, Master, MBA)
- **Écoles d'ingénieurs** (toutes années, notamment BUT, Licence Pro)
- **Universités** (Licence, Master, programmes internationaux)
- **BTS** (Commerce international, Tourisme, Communication, etc.)
- **Centres de formation professionnelle** (formation continue, reconversion)
- **Organismes de formation linguistique** (cours privés, stages intensifs)

### Caractéristiques du public

- **Âge** : 18-35 ans principalement (étudiants et jeunes professionnels)
- **Objectif** : Obtenir un score TOEIC entre **550 et 900 points**
- **Motivation** : Validation de diplôme, insertion professionnelle, mobilité internationale
- **Contrainte** : Besoin de flexibilité (révision autonome + séances encadrées)
- **Niveau d'anglais** : De B1 (intermédiaire) à C1 (autonome), selon le CECRL

---

## 3. Objectifs pédagogiques

### Objectifs primaires

1. **Amélioration du score TOEIC**
   - Progression mesurable sur l'échelle 10-990 points
   - Ciblage des parties les plus faibles (Listening, Reading)
   - Maîtrise des stratégies spécifiques à chaque partie (Parts 1-7)

2. **Développement de l'autonomie**
   - Capacité à s'auto-évaluer et identifier ses lacunes
   - Apprentissage de techniques d'entraînement efficaces
   - Gestion optimale du temps d'examen (45 min Listening, 75 min Reading)

3. **Réduction du stress et de l'anxiété**
   - Familiarisation avec le format et les types de questions
   - Confiance en soi grâce aux simulations répétées
   - Feedback positif et encouragements personnalisés

### Objectifs secondaires

4. **Renforcement des compétences linguistiques globales**
   - Vocabulaire du monde professionnel et quotidien
   - Grammaire anglaise (temps, structures, prépositions)
   - Compréhension orale (accents américain, britannique, canadien, australien)
   - Compréhension écrite (emails, rapports, annonces, articles)

5. **Préparation aux variantes du TOEIC**
   - Ouverture vers le TOEIC Speaking & Writing si nécessaire
   - Adaptation aux formats 4-Skills pour certains établissements
   - Transition possible vers d'autres certifications (TOEFL, IELTS)

---

## 4. Fonctions clés de l'agent

### 4.1 Diagnostic de niveau initial

**Fonctionnement :**
- Questionnaire de présentation (score actuel, score cible, date d'examen, difficultés perçues)
- Mini-test de positionnement (15-20 questions représentatives des 7 parties)
- Analyse automatique des réponses et identification des points forts/faibles

**Résultat :**
- Estimation du niveau actuel (score TOEIC estimé)
- Rapport détaillé par compétence (Listening Part 1-4, Reading Part 5-7)
- Recommandations de démarrage (par où commencer, combien d'heures par semaine)

### 4.2 Entraînement ciblé par parties

**Listening (100 questions, ~45 minutes)**

- **Part 1 - Photographs (6 questions)** : Entraînement à la description d'images, vocabulaire visuel, choix de la meilleure description
- **Part 2 - Question-Response (25 questions)** : Compréhension de questions courtes et réponses appropriées, détection des distracteurs
- **Part 3 - Conversations (39 questions)** : Dialogues entre 2-3 personnes, identification des rôles, intentions, détails spécifiques
- **Part 4 - Talks (30 questions)** : Monologues (annonces, publicités, instructions), compréhension globale et détaillée

**Reading (100 questions, 75 minutes)**

- **Part 5 - Incomplete Sentences (30 questions)** : Grammaire, vocabulaire, choix de la bonne forme/mot pour compléter une phrase
- **Part 6 - Text Completion (16 questions)** : Textes à trous (mots, phrases, grammaire en contexte)
- **Part 7 - Reading Comprehension (54 questions)** :
  - 29 questions sur passages simples (emails, annonces, articles)
  - 25 questions sur passages multiples (double/triple textes liés)

**Capacités de l'agent par partie :**
- Générer des exercices originaux respectant le format officiel
- Adapter la difficulté au niveau de l'étudiant (B1, B2, C1)
- Proposer des variantes pour éviter la répétition
- Expliquer les réponses en français avec détails linguistiques

### 4.3 Simulation de mini-examens TOEIC

**Formats disponibles :**
- **Mini-test express** : 30 questions (15 Listening + 15 Reading) en 30 minutes
- **Test partiel** : 100 questions (50 Listening + 50 Reading) en 1h
- **Simulation complète** : 200 questions (100 Listening + 100 Reading) en 2h

**Fonctionnalités :**
- Chronomètre intégré avec gestion du temps par partie
- Conditions proches de l'examen réel (pas de retour en arrière dans certaines parties)
- Score estimé immédiatement après le test
- Correction détaillée question par question

### 4.4 Feedback détaillé et compréhensible

**Type de feedback fourni :**

- **Feedback immédiat** : Après chaque exercice, explication en français de la bonne réponse
- **Feedback linguistique** : Pourquoi telle option est correcte, règles de grammaire, nuances de vocabulaire
- **Feedback stratégique** : Comment repérer les pièges, techniques de réponse, gestion du temps
- **Feedback encourageant** : Valorisation des progrès, motivation, conseils pour continuer

**Format du feedback :**
- Langage clair et pédagogique (pas de jargon technique)
- Exemples concrets en anglais avec traduction/explication en français
- Conseils d'amélioration actionnables
- Références à des ressources complémentaires si besoin

### 4.5 Propositions de plans de révision personnalisés

**Paramètres pris en compte :**
- Niveau actuel et score cible (ex : de 550 à 750)
- Nombre de semaines disponibles (2, 4, 8, 12 semaines)
- Temps hebdomadaire disponible (3h, 5h, 10h)
- Points faibles identifiés (ex : grammaire Part 5, compréhension orale Part 3)

**Contenu du plan :**
- Répartition hebdomadaire des activités (par partie du TOEIC)
- Nombre d'exercices et de mini-tests par semaine
- Jalons de progression (tests intermédiaires)
- Ajustements possibles selon l'évolution

**Exemple de plan type (4 semaines, 5h/semaine, objectif 700) :**
- **Semaine 1** : Diagnostic + focus Part 5 et 6 (grammaire/vocabulaire)
- **Semaine 2** : Part 7 (lecture) + révision grammaire + mini-test
- **Semaine 3** : Part 2 et 3 (Listening) + révision vocabulaire + mini-test
- **Semaine 4** : Part 4 + révision complète + simulation complète

### 4.6 Suivi de la progression dans le temps

**Indicateurs suivis :**
- Évolution du score estimé au fil des tests
- Taux de réussite par partie (pourcentage de bonnes réponses)
- Temps moyen de réponse par question
- Nombre d'exercices réalisés et régularité
- Identification des types d'erreurs récurrentes

**Visualisation :**
- Graphiques de progression (score global, score par partie)
- Historique des tests passés
- Comparaison avant/après (diagnostic initial vs dernier test)
- Prévision du score le jour J (basée sur la courbe de progression)

**Alertes et recommandations :**
- Signalement si la progression stagne
- Suggestion d'ajuster le plan de révision
- Rappels de régularité si inactivité prolongée
- Encouragements lors de franchissement de paliers (600, 700, 800...)

---

## 5. Limites et précautions d'usage

### 5.1 Limites techniques et pédagogiques

**L'agent TOEIC Coach n'est PAS :**

❌ **Un fournisseur de sujets officiels** : L'agent ne peut pas reproduire ou distribuer les questions officielles du TOEIC protégées par copyright. Il génère des exercices *de type TOEIC* respectant le format, mais ce ne sont pas les vrais sujets d'examen.

❌ **Une garantie de résultat** : Le score obtenu dépend de nombreux facteurs (niveau initial, régularité, motivation, conditions le jour J). L'agent améliore les chances de réussite, mais ne peut garantir un score précis.

❌ **Un remplaçant du professeur** : L'agent est un outil complémentaire. Les enseignants apportent l'expertise pédagogique, la motivation humaine, l'adaptation fine au groupe et le cadre d'apprentissage. L'agent automatise la génération d'exercices et le feedback, mais ne remplace pas l'accompagnement humain.

❌ **Un évaluateur officiel** : Seuls les centres agréés ETS Global peuvent délivrer des scores TOEIC officiels. Les scores de l'agent sont des estimations pédagogiques pour guider l'entraînement.

### 5.2 Respect du format officiel sans copie

**Principe de fonctionnement :**

L'agent s'inspire de la **structure, du format et du type de questions** du TOEIC officiel (tel que décrit dans les guides ETS Global), mais **génère ses propres contenus originaux**. 

- **Ce qui est reproduit** : Format des questions (QCM à 4 choix), nombre de questions par partie, types d'exercices (photos, dialogues, textes à trous, passages)
- **Ce qui est original** : Le contenu précis des questions, images, textes, dialogues, vocabulaire utilisé

**Conformité pédagogique :**
- Respect des durées (45 min Listening, 75 min Reading)
- Respect des niveaux de difficulté (A2 à C1)
- Respect des thématiques professionnelles (bureaux, voyages, achats, services)
- Respect de la diversité des accents pour le Listening (américain, britannique, australien, canadien)

### 5.3 Rôle d'outil d'entraînement complémentaire

**Positionnement dans l'écosystème pédagogique :**

```
┌─────────────────────────────────────────┐
│   ENSEIGNANT (pilotage, motivation)     │
│   - Définit les objectifs               │
│   - Anime les séances                   │
│   - Suit la progression du groupe       │
│   - Ajuste la pédagogie                 │
└──────────────┬──────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────┐
│   AGENT TOEIC COACH (automatisation)    │
│   - Génère les exercices                │
│   - Corrige et explique                 │
│   - Propose des plans                   │
│   - Suit la progression individuelle    │
└──────────────┬──────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────┐
│   ÉTUDIANT (pratique, autonomie)        │
│   - S'entraîne régulièrement            │
│   - Identifie ses lacunes               │
│   - Progresse à son rythme              │
│   - Se prépare au test officiel         │
└─────────────────────────────────────────┘
```

**Recommandations d'usage :**

✅ **Utiliser l'agent pour** :
- La génération rapide d'exercices variés
- L'entraînement autonome entre les cours
- Le feedback instantané (l'étudiant ne reste pas bloqué)
- La personnalisation des parcours selon le niveau
- Le gain de temps pour l'enseignant (correction automatisée)

✅ **Conserver le rôle du professeur pour** :
- L'explication des concepts complexes en classe
- La motivation et le soutien psychologique
- Les stratégies d'examen avancées
- L'adaptation aux besoins spécifiques du groupe
- Les simulations en conditions réelles avec débriefing collectif

### 5.4 Conformité et éthique

**Protection des données** : Les données des étudiants (scores, progression) doivent être traitées conformément au RGPD. L'établissement doit informer les étudiants de l'usage de l'agent et de la conservation des données.

**Équité** : Tous les étudiants doivent avoir un accès égal à l'agent (pas de discrimination).

**Transparence** : Les étudiants doivent comprendre qu'ils utilisent un outil d'IA et que les contenus sont générés automatiquement.

---

## 6. Scénarios d'usage typiques

### Scénario 1 : Étudiante en école d'ingénieur visant 785 points

**Profil :**
- **Prénom** : Léa
- **Niveau** : 3e année école d'ingénieur (BUT3 ou cycle ingénieur)
- **Niveau d'anglais** : B2 (bon niveau scolaire, quelques lacunes en vocabulaire professionnel)
- **Score actuel** : 650 estimé (test blanc initial)
- **Score cible** : 785 (requis pour valider le diplôme d'ingénieur)
- **Date d'examen** : Dans 8 semaines
- **Temps disponible** : 5h/semaine (3h autonome + 2h cours)

**Utilisation de l'agent :**

1. **Semaine 1 : Diagnostic**
   - Léa passe un test de positionnement de 30 questions via l'agent
   - Résultat : 650 estimé, points faibles identifiés = Part 5 (grammaire), Part 7 (lecture rapide de passages multiples)
   - L'agent propose un plan de 8 semaines focalisé sur ces parties

2. **Semaines 2-4 : Entraînement ciblé**
   - Léa utilise l'agent 3h/semaine en autonomie (exercices Part 5 et 7)
   - L'agent génère 30 questions de grammaire par session + explications détaillées en français
   - Léa lit 2-3 passages doubles/triples par session avec feedback immédiat
   - En cours (2h/semaine) : le professeur consolide avec des exercices collectifs et explique les pièges courants

3. **Semaines 5-6 : Simulations partielles**
   - Léa passe un mini-test (100 questions, 1h) chaque semaine via l'agent
   - Score en progression : 680 (semaine 5), 720 (semaine 6)
   - L'agent ajuste le plan : moins de Part 5 (maîtrisée), plus de Part 7 et Part 3 (Listening conversations)

4. **Semaine 7 : Simulation complète**
   - Simulation complète (200 questions, 2h) en conditions d'examen
   - Score estimé : 760
   - L'agent identifie les derniers points faibles (quelques erreurs de vocabulaire Part 6)

5. **Semaine 8 : Révision finale**
   - Léa révise avec l'agent les types d'erreurs récurrentes (vocabulaire professionnel, expressions idiomatiques)
   - Dernière simulation partielle (50 questions) : 780 estimé
   - **Résultat le jour J** : Léa obtient 790 au TOEIC officiel ✅

**Bénéfice de l'agent** : Léa a pu s'entraîner de manière ciblée et flexible, avec un volume d'exercices impossible à fournir manuellement par le professeur. La progression régulière (650 → 790) a été facilitée par le feedback immédiat et les plans personnalisés.

---

### Scénario 2 : Étudiant BTS visant 600 points

**Profil :**
- **Prénom** : Karim
- **Niveau** : BTS Commerce International, 2e année
- **Niveau d'anglais** : B1 (niveau scolaire correct, peu de pratique orale)
- **Score actuel** : 480 estimé (test blanc)
- **Score cible** : 600 (requis pour valider le BTS)
- **Date d'examen** : Dans 12 semaines
- **Temps disponible** : 4h/semaine (2h cours + 2h autonome)

**Utilisation de l'agent :**

1. **Semaines 1-2 : Diagnostic et bases**
   - Karim passe le diagnostic : 480 estimé
   - Points faibles : vocabulaire limité (Part 5, 6), compréhension orale Part 2 (questions-réponses rapides)
   - L'agent propose un plan débutant sur 12 semaines avec focus vocabulaire de base et grammaire essentielle

2. **Semaines 3-6 : Renforcement du vocabulaire et grammaire**
   - Karim utilise l'agent 2h/semaine en autonomie : 20 questions Part 5 par session (temps verbaux, prépositions, choix de mots)
   - L'agent fournit des explications en français avec exemples simples
   - En cours : le professeur complète avec des exercices oraux et des mises en situation

3. **Semaines 7-9 : Entraînement Listening**
   - Karim s'entraîne sur Part 1 (photos) et Part 2 (question-réponse) via l'agent
   - L'agent génère des dialogues courts avec accents variés
   - Karim écoute, répond, obtient le feedback immédiat avec transcription

4. **Semaines 10-11 : Mini-tests et consolidation**
   - Karim passe 2 mini-tests (50 questions, 30 min) par semaine
   - Score en progression : 520 (semaine 10), 570 (semaine 11)
   - L'agent identifie que Part 7 (lecture) reste difficile : focus sur les passages simples (emails, annonces)

5. **Semaine 12 : Révision et confiance**
   - Dernière simulation complète : 610 estimé
   - L'agent génère une fiche récap des 50 mots de vocabulaire clés à revoir
   - **Résultat le jour J** : Karim obtient 605 au TOEIC officiel ✅

**Bénéfice de l'agent** : Karim, de niveau B1 initial, a pu combler ses lacunes grâce à un entraînement progressif et répétitif sans surcharger le professeur. Le feedback en français a été clé pour comprendre les erreurs.

---

### Scénario 3 : Salarié en formation continue visant 750 points

**Profil :**
- **Prénom** : Sophie
- **Âge** : 32 ans
- **Situation** : Salariée en reconversion (formation financée par le CPF)
- **Niveau d'anglais** : B2 (pratique professionnelle à l'oral, peu d'écrit formel)
- **Score actuel** : 680 estimé
- **Score cible** : 750 (requis pour postuler à l'international)
- **Date d'examen** : Dans 4 semaines (formation intensive)
- **Temps disponible** : 10h/semaine (6h cours intensifs + 4h autonome)

**Utilisation de l'agent :**

1. **Semaine 1 : Diagnostic express et plan accéléré**
   - Sophie passe un diagnostic complet (30 questions)
   - Résultat : 680, points faibles = Part 6 (textes à trous en contexte), Part 4 (monologues longs)
   - L'agent propose un plan intensif de 4 semaines avec 2 simulations complètes

2. **Semaines 2-3 : Entraînement intensif**
   - Sophie utilise l'agent 4h/semaine en autonomie (soir et week-end)
   - Part 6 : 20 textes à trous par semaine avec feedback détaillé
   - Part 4 : écoute de 15 monologues (annonces, publicités, instructions) avec questions
   - En formation (6h/semaine) : simulations partielles et débriefings collectifs avec le formateur

3. **Semaine 4 : Simulations et ajustements**
   - Sophie passe 2 simulations complètes (une en cours, une en autonome via l'agent)
   - Scores : 720 (simulation 1), 745 (simulation 2)
   - L'agent identifie encore quelques erreurs Part 5 (vocabulaire formel) : révision ciblée des 30 derniers mots clés

4. **Jour de l'examen**
   - **Résultat** : Sophie obtient 755 au TOEIC officiel ✅

**Bénéfice de l'agent** : Pour Sophie, le rythme intensif nécessitait un volume massif d'exercices. L'agent a permis de générer des contenus variés sans limite, et le feedback immédiat a maximisé l'efficacité de son temps d'étude autonome.

---

### Scénario 4 : Étudiant Master visant 850 points (C1)

**Profil :**
- **Prénom** : Thomas
- **Niveau** : Master 1 école de commerce, parcours international
- **Niveau d'anglais** : C1 (très bon niveau, pratique courante)
- **Score actuel** : 800 estimé
- **Score cible** : 850+ (pour se démarquer sur le marché du travail)
- **Date d'examen** : Dans 6 semaines
- **Temps disponible** : 3h/semaine (préparation en autonomie)

**Utilisation de l'agent :**

1. **Semaine 1 : Diagnostic niveau avancé**
   - Thomas passe un test de 50 questions (niveau C1)
   - Résultat : 800, peu de faiblesses, mais quelques erreurs de vocabulaire très formel (Part 5) et de compréhension fine (Part 7 passages multiples complexes)

2. **Semaines 2-5 : Entraînement niveau expert**
   - Thomas utilise l'agent 3h/semaine : exercices de niveau C1 uniquement (vocabulaire business avancé, textes complexes)
   - L'agent génère des passages Part 7 avec 3 textes interconnectés (cas d'entreprise, correspondances, rapports)
   - Feedback de l'agent : nuances fines de vocabulaire, expressions idiomatiques professionnelles

3. **Semaine 6 : Simulations et peaufinage**
   - Thomas passe 2 simulations complètes
   - Scores : 840, 860
   - **Résultat le jour J** : Thomas obtient 865 au TOEIC officiel ✅

**Bénéfice de l'agent** : Thomas, déjà de très bon niveau, a pu s'entraîner sur des exercices de difficulté maximale sans avoir besoin de cours supplémentaires. L'agent a généré des contenus C1 adaptés, difficiles à trouver dans les manuels standard.

---

### Scénario 5 : Classe de 25 étudiants en école de management

**Profil :**
- **Établissement** : École de management, Bachelor 3e année
- **Taille de la classe** : 25 étudiants
- **Niveau d'anglais** : Hétérogène (B1 à C1)
- **Score cible** : Minimum 785 pour valider le diplôme
- **Durée** : Semestre (12 semaines, 2h de cours/semaine)
- **Contrainte** : Hétérogénéité importante (de 550 à 850 estimé)

**Utilisation de l'agent :**

1. **Semaine 1 : Diagnostic de groupe**
   - Tous les étudiants passent le diagnostic via l'agent (30 min en salle informatique)
   - Le professeur collecte les résultats dans un tableur de suivi
   - Résultat : 
     - 8 étudiants niveau B1 (550-650)
     - 12 étudiants niveau B2 (650-750)
     - 5 étudiants niveau C1 (750-850)

2. **Semaines 2-10 : Différenciation pédagogique**
   - **En cours (2h/semaine)** : Le professeur anime des séances thématiques (stratégies Part 7, pièges Part 5, etc.)
   - **En autonomie (3-5h/semaine)** : Chaque étudiant utilise l'agent selon son niveau
     - Étudiants B1 : exercices de base (vocabulaire, grammaire simple)
     - Étudiants B2 : exercices intermédiaires (textes moyens, dialogues)
     - Étudiants C1 : exercices avancés (passages complexes, vocabulaire business)
   - L'agent génère des parcours personnalisés selon le niveau de chacun

3. **Semaines 11-12 : Simulations et consolidation**
   - Tous les étudiants passent une simulation complète en cours (2h)
   - Le professeur utilise le tableur de suivi pour identifier les étudiants encore en dessous de 785
   - L'agent génère des plans de révision ciblés pour les étudiants en difficulté

4. **Résultats le jour J**
   - **23 étudiants sur 25** obtiennent 785+ au TOEIC officiel ✅
   - 2 étudiants obtiennent 760 et 770 (en léger progrès, pourront repasser)

**Bénéfice de l'agent** : Le professeur a pu gérer l'hétérogénéité grâce à la différenciation automatique de l'agent. Chaque étudiant a reçu un entraînement adapté à son niveau, sans nécessiter 3 niveaux de cours différents.

---

## 7. Conclusion

L'agent TOEIC Coach est un **outil pédagogique innovant et efficace** pour accompagner la préparation au TOEIC dans les établissements d'enseignement supérieur et les centres de formation. 

**Points clés à retenir :**

✅ **Complémentarité** : L'agent automatise la génération d'exercices et le feedback, libérant du temps pour le professeur qui se concentre sur la pédagogie et la motivation.

✅ **Personnalisation** : Chaque étudiant suit un parcours adapté à son niveau (B1 à C1) et ses objectifs (550 à 900 points).

✅ **Flexibilité** : Disponible 24h/24, l'agent permet l'entraînement autonome entre les cours, essentiel pour progresser rapidement.

✅ **Suivi de progression** : Les données collectées permettent au professeur et à l'étudiant de visualiser les progrès et d'ajuster la stratégie.

✅ **Conformité** : L'agent respecte le format TOEIC officiel sans copier les vrais sujets, dans un cadre éthique et légal.

**Conditions de réussite :**
- Engagement régulier des étudiants (3-5h/semaine minimum)
- Suivi attentif du professeur (vérification hebdomadaire de l'utilisation)
- Intégration dans le cursus (pas un outil "en plus", mais partie intégrante de la formation)
- Ressources techniques disponibles (ordinateurs, connexion, écouteurs pour le Listening)

**L'agent TOEIC Coach est votre partenaire pour transformer la préparation TOEIC en expérience d'apprentissage moderne, efficace et motivante.**
