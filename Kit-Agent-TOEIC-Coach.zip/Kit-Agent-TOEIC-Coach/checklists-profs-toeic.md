# Checklists pour les profs TOEIC Coach

Ce document propose 3 checklists pratiques pour faciliter le pilotage de la préparation TOEIC avec l'agent TOEIC Coach. Ces checklists sont imprimables et utilisables directement par les enseignants.

---

## CHECKLIST 1 : Onboarding de l'agent TOEIC Coach

### Étape préalable : Définir les objectifs de la classe

☐ **Identifier le score cible minimal** requis par l'établissement (ex : 785 pour diplôme d'ingénieur, 600 pour BTS)

☐ **Définir la date d'examen officiel** (planifier les séances en conséquence)

☐ **Estimer le niveau global de la classe** (B1, B2, C1, ou hétérogène)

☐ **Recenser le nombre d'étudiants** et vérifier les contraintes techniques (nombre d'ordinateurs, licences d'accès à l'agent)

☐ **Définir le volume horaire** disponible (nombre de semaines × heures de cours par semaine)

---

### Configuration de l'agent TOEIC Coach

☐ **Obtenir les accès** à l'agent (identifiants, liens, licences pour l'établissement)

☐ **Tester l'agent en amont** : générer quelques exercices, vérifier la qualité des feedbacks, tester les différentes parties (Parts 1-7)

☐ **Configurer le prompt système** (voir document "Bibliothèque de prompts") avec les paramètres de votre classe :
   - Niveau cible (B1-C1)
   - Score cible (550-900)
   - Durée de la formation (nombre de semaines)

☐ **Préparer des comptes d'accès individuels** pour chaque étudiant (ou un accès collectif selon la solution technique)

☐ **Créer le tableur de suivi de progression** (voir document "Suivi de progression TOEIC") et le partager avec les étudiants

---

### Consignes à donner aux étudiants (séance d'introduction)

☐ **Présenter l'agent TOEIC Coach** : son rôle, ce qu'il peut faire (génération d'exercices, feedback immédiat, plans de révision), ce qu'il ne peut PAS faire (remplacer le professeur, garantir un score)

☐ **Démontrer en direct** comment utiliser l'agent :
   - Se connecter
   - Demander un exercice par partie (ex : "Génère 10 questions Part 5 niveau B2")
   - Lire le feedback en français
   - Noter son score dans le tableur de suivi

☐ **Donner les consignes d'usage** :
   - Fréquence recommandée : **3-5 heures par semaine minimum** en travail autonome
   - Répartition conseillée : 30-60 minutes par jour (mieux que 3h en une fois)
   - Alternance Listening / Reading (ne pas faire que Reading, qui est plus facile)
   - Régularité : l'agent est disponible 24h/24, profitez-en

☐ **Préciser les règles d'utilisation** :
   - Utilisation individuelle (pas de partage de compte)
   - Honnêteté dans les réponses (ne pas tricher, c'est pour progresser)
   - Reporting des bugs ou difficultés techniques au professeur

---

### Points à vérifier avant le lancement

☐ **Matériel technique disponible** :
   - Ordinateurs ou tablettes avec connexion Internet
   - Écouteurs pour les exercices Listening
   - Salle informatique réservée pour les séances en classe si nécessaire

☐ **Tous les étudiants ont reçu** :
   - Les identifiants d'accès à l'agent
   - Le lien vers le tableur de suivi
   - Le document "Bibliothèque de prompts" (pour savoir quels exercices demander)
   - Le calendrier des séances et des tests

☐ **Test de connexion réussi** : tous les étudiants ont pu se connecter et générer au moins un exercice test

☐ **Date du diagnostic initial fixée** (idéalement séance 1, semaine 1)

---

### Checklist d'onboarding complétée ✓

☐ **Tous les points ci-dessus sont cochés → l'agent TOEIC Coach est prêt à être déployé**

---

## CHECKLIST 2 : Suivi hebdomadaire de la préparation TOEIC

### À vérifier chaque semaine

#### Utilisation de l'agent par les étudiants

☐ **Consulter le tableur de suivi** : vérifier que tous les étudiants ont renseigné leurs scores de la semaine (exercices réalisés, mini-tests)

☐ **Identifier les étudiants inactifs** (moins de 2h d'utilisation de l'agent dans la semaine) :
   - Liste des étudiants concernés : ________________________
   - Action : les contacter individuellement pour comprendre la raison (manque de temps, démotivation, difficulté technique)

☐ **Identifier les étudiants très actifs** (plus de 8h/semaine) :
   - Liste des étudiants concernés : ________________________
   - Action : vérifier qu'ils ne se dispersent pas, qu'ils travaillent de manière ciblée (pas uniquement des parties faciles)

☐ **Vérifier l'équilibre Listening / Reading** :
   - Est-ce que les étudiants travaillent les deux sections ou se concentrent-ils trop sur Reading (plus facile) ?
   - Action si déséquilibre : rappeler l'importance du Listening, proposer des exercices guidés en classe

---

#### Progression de la classe

☐ **Analyser les scores moyens** de la semaine (mini-tests) :
   - Score moyen actuel de la classe : ______ / 990
   - Progression par rapport à la semaine dernière : +/- ______ points
   - Score cible moyen à atteindre : ______ / 990

☐ **Identifier les parties les plus faibles** de la classe (en moyenne) :
   - Part(s) la(les) plus faible(s) : Part _____ (score moyen : _____ %)
   - Action : prévoir une séance ciblée sur cette partie la semaine prochaine

☐ **Identifier les étudiants en difficulté** (score stagnant ou en baisse) :
   - Liste des étudiants concernés : ________________________
   - Action : proposer un entretien individuel, ajuster le plan de révision, orienter vers des exercices de niveau B1 si nécessaire

☐ **Identifier les étudiants en forte progression** (gain de +30 points ou plus) :
   - Liste des étudiants concernés : ________________________
   - Action : les féliciter publiquement (motivation du groupe), leur proposer des exercices de niveau supérieur (C1)

---

#### Actions à mener selon les signaux

**SI score moyen de la classe stagne depuis 2 semaines :**

☐ Organiser une **séance de révision ciblée** sur les parties les plus faibles

☐ Proposer un **mini-test collectif en classe** pour remotiver et identifier les blocages en conditions réelles

☐ Ajuster les **plans de révision individuels** via l'agent (focus sur les points faibles)

---

**SI plusieurs étudiants sont inactifs :**

☐ **Envoyer un rappel collectif** (email ou annonce en classe) sur l'importance de la régularité

☐ **Contacter individuellement** les étudiants inactifs pour comprendre les raisons (problèmes personnels, démotivation, difficulté technique)

☐ **Proposer une séance de rattrapage** ou un soutien supplémentaire

---

**SI des étudiants ne comprennent pas les feedbacks de l'agent :**

☐ **Organiser une séance de questions/réponses** pour clarifier les explications grammaticales ou de vocabulaire

☐ **Créer une FAQ** avec les questions les plus fréquentes et les explications complémentaires

---

**SI des étudiants progressent très rapidement et atteignent déjà leur score cible :**

☐ **Les encourager à viser un score supérieur** (ex : 800 → 850, ou 750 → 800)

☐ **Leur proposer des exercices de niveau C1** ou des passages multiples complexes pour continuer à progresser

☐ **Les valoriser comme "tuteurs" de la classe** (ils peuvent aider les étudiants en difficulté)

---

### Checklist hebdomadaire complétée ✓

☐ **Tous les points ci-dessus sont vérifiés → suivi de la semaine effectué**

☐ **Actions correctives planifiées** pour la semaine prochaine (si nécessaire)

---

## CHECKLIST 3 : Préparation finale "Avant Examen"

### 2-3 semaines avant l'examen officiel

#### Vérification du niveau de préparation

☐ **Chaque étudiant a passé au moins 3 mini-tests complets** (100-200 questions) via l'agent :
   - Nombre de mini-tests moyen par étudiant : ______
   - Action si insuffisant : imposer 1-2 simulations complètes avant l'examen

☐ **Chaque étudiant connaît son score estimé actuel** et l'écart avec son score cible :
   - Nombre d'étudiants ayant atteint leur score cible : ______ / ______
   - Nombre d'étudiants à moins de 50 points du score cible : ______ / ______
   - Nombre d'étudiants à plus de 50 points du score cible : ______ / ______ (nécessitent soutien intensif)

☐ **Chaque étudiant a identifié ses 2-3 faiblesses principales** (parties où il fait le plus d'erreurs) :
   - Liste des faiblesses récurrentes dans la classe : ________________________
   - Action : organiser une séance de révision ciblée sur ces parties

---

#### Stratégies d'examen maîtrisées

☐ **Gestion du temps** :
   - Tous les étudiants connaissent la répartition recommandée du temps :
     - Listening : ~45 minutes (imposé par l'audio)
     - Reading : 75 minutes (Part 5 : 10-12 min, Part 6 : 8-10 min, Part 7 : 50-55 min)
   - Les étudiants ont pratiqué des exercices chronométrés et savent gérer leur rythme

☐ **Stratégie de "guessing" intelligent** :
   - Les étudiants savent qu'il faut répondre à TOUTES les questions (pas de points négatifs)
   - En cas de doute : éliminer 1-2 réponses évidemment fausses, puis choisir parmi les restantes
   - En cas de panique : choisir toujours la même lettre (A, B, C ou D) pour gagner du temps

☐ **Stratégies par partie** :
   - **Part 1 (Photos)** : Se concentrer sur les verbes et les prépositions (où, qui, quoi)
   - **Part 2 (Question-Response)** : Écouter le premier mot de la question (Who, What, Where, When, Why, How) pour anticiper le type de réponse
   - **Part 3-4 (Conversations/Talks)** : Lire les questions AVANT l'écoute, prendre des notes (noms, chiffres, lieux)
   - **Part 5 (Incomplete Sentences)** : Identifier rapidement le type de question (grammaire ou vocabulaire), éliminer les distracteurs, répondre en 20-30 secondes maximum
   - **Part 6 (Text Completion)** : Lire le texte entier avant de répondre (contexte important)
   - **Part 7 (Reading)** : Lire les questions AVANT le texte, scanner pour trouver les réponses, ne pas bloquer sur un passage difficile

---

#### Préparation matérielle et logistique

☐ **Chaque étudiant connaît** :
   - La date, l'heure, et le lieu exact de l'examen TOEIC officiel
   - Les documents à apporter (pièce d'identité, convocation, crayon HB, gomme)
   - L'interdiction d'apporter téléphone, montre connectée, dictionnaire

☐ **Rappel des consignes d'examen officiel** :
   - Pas de communication entre candidats
   - Pas de retour en arrière dans la partie Listening (les audios ne sont joués qu'une fois)
   - Possibilité de revenir en arrière dans la partie Reading (gérer son temps)
   - Remplir la feuille de réponse avec soin (cases cochées proprement)

☐ **Conseils de préparation physique et mentale** :
   - Bien dormir la veille (7-8h de sommeil)
   - Manger équilibré le matin de l'examen (éviter le ventre vide ou trop lourd)
   - Arriver 20-30 minutes en avance (éviter le stress du retard)
   - Respirer profondément si stress pendant l'examen (pause de 30 secondes pour se recentrer)

---

#### Validation des connaissances clés

☐ **Chaque étudiant a révisé et maîtrise** :
   - Les 50-100 mots de vocabulaire professionnel clés (RH, finance, marketing, logistique, voyages)
   - Les temps verbaux essentiels (présent, passé, futur, present perfect, conditionnel)
   - Les prépositions courantes (in, on, at, for, since, during, by, with, etc.)
   - Les connecteurs logiques (however, therefore, in addition, for example, nevertheless, etc.)

☐ **Fiche récapitulative distribuée** (1 page recto-verso avec l'essentiel) :
   - Répartition du temps par partie
   - Stratégies clés
   - Liste des 50 mots de vocabulaire incontournables
   - Conseils de gestion du stress

---

#### Dernière simulation complète (obligatoire)

☐ **Organiser une simulation complète (200 questions, 2h)** en conditions réelles :
   - Date de la simulation : ________________
   - Lieu : ________________ (salle au calme, avec ordinateurs et écouteurs)
   - Consignes d'examen respectées (silence, chronomètre, pas de téléphone)

☐ **Débriefing après la simulation** :
   - Chaque étudiant a reçu son score estimé final
   - Chaque étudiant a identifié les 2-3 derniers points à travailler d'ici l'examen
   - Le professeur a rassuré et encouragé la classe (le score de simulation n'est pas le score final, il reste quelques jours pour progresser)

---

#### Actions finales (dernière semaine)

☐ **Rappel de motivation** : envoyer un message collectif encourageant, rappeler les progrès réalisés depuis le début de la formation

☐ **Révision légère** (pas de surcharge) :
   - Les étudiants font 20-30 questions par jour via l'agent (pour maintenir le rythme)
   - Pas de nouvelle notion à apprendre, seulement réviser l'existant
   - Relire les fiches de vocabulaire et de stratégies

☐ **Gestion du stress** :
   - Rappeler que le TOEIC est un test, pas un examen de vie ou de mort
   - Valoriser les compétences acquises (même sans score parfait)
   - Encourager la visualisation positive (imaginer le jour J se dérouler sereinement)

☐ **Derniers conseils le jour J** :
   - Se détendre la veille (pas de révision intensive, sortir, se changer les idées)
   - Dormir suffisamment
   - Arriver en avance, confiant(e), et bien préparé(e)

---

### Checklist "Avant Examen" complétée ✓

☐ **Tous les points ci-dessus sont cochés → la classe est prête pour l'examen officiel**

☐ **Score cible collectif réaliste** : ______ % des étudiants devraient atteindre leur score cible

---

## NOTES D'UTILISATION DES CHECKLISTS

### Fréquence d'utilisation

- **Checklist 1 (Onboarding)** : À utiliser **une seule fois** en début de formation (semaine 0-1)
- **Checklist 2 (Suivi hebdomadaire)** : À utiliser **chaque semaine** pendant toute la durée de la formation
- **Checklist 3 (Avant Examen)** : À utiliser **2-3 semaines avant l'examen officiel** (séance de préparation finale)

### Personnalisation

Ces checklists sont des modèles génériques. N'hésitez pas à :

- Ajouter des points spécifiques à votre établissement (exigences de score, contraintes techniques, etc.)
- Adapter les seuils (ex : "inactif = moins de 3h/semaine" au lieu de 2h, selon votre contexte)
- Traduire en anglais si vous travaillez dans un contexte international

### Conservation

- **Imprimez ces checklists** et conservez-les dans votre classeur de préparation TOEIC
- **Cochez les cases** au fur et à mesure pour garder une trace de votre suivi
- **Archivez les checklists complétées** en fin de formation pour capitaliser sur l'expérience et améliorer les prochaines sessions

---

**Avec ces 3 checklists, vous disposez d'un pilotage structuré et efficace de la préparation TOEIC. Bonne formation !**
