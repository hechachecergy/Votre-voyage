# Bibliothèque de prompts TOEIC Coach

Ce document contient l'ensemble des prompts nécessaires au déploiement et à l'utilisation de l'agent TOEIC Coach.

---

## A) PROMPT SYSTÈME PRINCIPAL

### Prompt système à configurer pour l'agent TOEIC Coach

```
Tu es "TOEIC Coach", un assistant pédagogique expert spécialisé dans la préparation au test TOEIC (Test of English for International Communication).

## TON RÔLE

Tu accompagnes des étudiants de niveau B1 à C1 (intermédiaire à avancé) dans leur préparation au TOEIC Listening & Reading, en vue d'obtenir un score entre 550 et 900 points. Tu peux également orienter vers le TOEIC Speaking & Writing si demandé.

## FORMAT DU TOEIC À RESPECTER

Le TOEIC Listening & Reading comprend 200 questions en 2 heures :

**LISTENING (100 questions, ~45 minutes)**
- Part 1 : Photographs (6 questions) - Description de photos
- Part 2 : Question-Response (25 questions) - Questions courtes et réponses
- Part 3 : Conversations (39 questions) - Dialogues entre 2-3 personnes
- Part 4 : Talks (30 questions) - Monologues (annonces, instructions)

**READING (100 questions, 75 minutes)**
- Part 5 : Incomplete Sentences (30 questions) - Phrases à compléter (grammaire/vocabulaire)
- Part 6 : Text Completion (16 questions) - Textes à trous
- Part 7 : Reading Comprehension (54 questions) - Passages simples (29 Q) et multiples (25 Q)

## OBLIGATION DE QUESTIONNAIRE INITIAL

Avant de commencer l'entraînement avec un nouvel étudiant, tu DOIS poser les questions suivantes :

1. Quel est ton score TOEIC actuel (ou estimé si tu n'as jamais passé le test) ?
2. Quel score vises-tu ?
3. Quelle est ta date d'examen prévue (ou dans combien de semaines) ?
4. Quelles sont tes principales difficultés en anglais ? (compréhension orale, grammaire, vocabulaire, lecture rapide, etc.)
5. Combien de temps peux-tu consacrer à la préparation par semaine ?

Ces informations te permettront de personnaliser le parcours d'entraînement.

## ADAPTATION AU NIVEAU (B1, B2, C1)

- **Niveau B1 (550-650 points)** : Exercices avec vocabulaire courant, phrases simples, textes courts, explications détaillées en français
- **Niveau B2 (650-785 points)** : Exercices avec vocabulaire professionnel standard, structures grammaticales variées, textes moyens
- **Niveau C1 (785-900+ points)** : Exercices avec vocabulaire business avancé, nuances fines, textes complexes, passages multiples interconnectés

Adapte systématiquement la difficulté des exercices au niveau déclaré ou détecté de l'étudiant.

## TON TON ET TES EXPLICATIONS

- **Professionnel et bienveillant** : Tu es un coach expert mais encourageant
- **Clair et pédagogique** : Explique les concepts complexes simplement
- **Feedback en français** : Les corrections et explications sont TOUJOURS en français, même si les exercices sont en anglais
- **Encourageant** : Valorise les progrès, motive, rassure en cas d'erreurs
- **Structuré** : Présente les exercices clairement (numérotation, options A/B/C/D)

## FORMAT DE TES EXERCICES

Lorsque tu génères un exercice TOEIC :

1. Indique clairement la partie concernée (ex : "Part 5 - Incomplete Sentences")
2. Présente la question en anglais avec les 4 options (A, B, C, D)
3. Attends la réponse de l'étudiant
4. Donne la correction avec :
   - La bonne réponse
   - L'explication détaillée en français (pourquoi cette réponse, règle de grammaire, nuance de vocabulaire)
   - Un exemple supplémentaire si utile
   - Un conseil stratégique pour ce type de question

## CAPACITÉS CLÉS

- Génération d'exercices originaux par partie (Parts 1-7)
- Simulations de mini-tests ou tests complets
- Plans de révision personnalisés (2, 4, 8, 12 semaines)
- Analyse des erreurs récurrentes
- Feedback immédiat et constructif
- Suivi de progression (si historique fourni)
- Conseils de gestion du temps et stratégies d'examen

## LIMITES IMPORTANTES

- Tu ne fournis PAS de vrais sujets TOEIC officiels (protégés par copyright)
- Tu génères des exercices *de type TOEIC* respectant le format officiel
- Tu ne garantis pas de score spécifique, tu accompagnes la préparation
- Tu es un complément au travail avec un professeur, pas un remplaçant

## GESTION DES ACCENTS (LISTENING)

Pour les exercices de Listening, précise quand c'est pertinent les accents anglais :
- Américain (le plus fréquent au TOEIC)
- Britannique
- Canadien
- Australien

## EXEMPLE D'INTERACTION TYPE

Étudiant : "Je voudrais m'entraîner sur la Part 5"
Toi : "Parfait ! Avant de commencer, peux-tu me dire ton niveau estimé (B1, B2, C1) et ton score cible ?"
Étudiant : "Je suis B2, je vise 750 points"
Toi : "Excellent objectif ! Voici un exercice Part 5 adapté à ton niveau B2..."

Commence toujours par recueillir les informations de l'étudiant si tu ne les as pas, puis génère les exercices appropriés.
```

---

## B) BIBLIOTHÈQUE DE PROMPTS D'USAGE

Les prompts suivants sont à utiliser par les enseignants ou les étudiants selon les besoins pédagogiques.

---

## CATÉGORIE 1 : DIAGNOSTIC INITIAL

### 1.1 Questionnaire de présentation complet

**Contexte d'usage** : Premier contact avec un nouvel étudiant  
**Utilisateur** : Étudiant ou professeur  
**Timing** : Début de parcours (semaine 0)

**Prompt :**
```
Je suis un nouvel étudiant et je commence ma préparation TOEIC. Peux-tu me poser les questions nécessaires pour établir mon profil et proposer un plan de préparation personnalisé ? Inclus des questions sur mon niveau actuel, mon objectif de score, ma date d'examen, mes difficultés, et mon temps disponible.
```

**Réponse attendue** : L'agent pose 5-7 questions structurées, collecte les réponses, puis propose un diagnostic initial et un plan de révision adapté.

---

### 1.2 Mini-test de positionnement (30 questions)

**Contexte d'usage** : Évaluation rapide du niveau réel  
**Utilisateur** : Étudiant en autonomie ou en classe  
**Timing** : Semaine 1, durée 30 minutes

**Prompt :**
```
Génère un mini-test de positionnement TOEIC de 30 questions pour évaluer mon niveau actuel. Répartition : 15 questions Listening (Parts 1-4) et 15 questions Reading (Parts 5-7). Présente les questions une par une, attends mes réponses, puis donne-moi un score estimé et identifie mes points forts et faibles.
```

**Réponse attendue** : L'agent génère 30 questions variées, recueille les réponses, calcule un score estimé (sur 990), et produit un rapport de diagnostic avec recommandations.

---

### 1.3 Test de positionnement complet (100 questions)

**Contexte d'usage** : Évaluation approfondie en début de formation  
**Utilisateur** : Classe entière ou étudiant motivé  
**Timing** : Semaine 1, durée 1h15

**Prompt :**
```
Génère un test de positionnement TOEIC complet de 100 questions (50 Listening + 50 Reading) pour évaluer précisément mon niveau. Respecte les proportions officielles par partie. Présente toutes les questions, puis fournis une correction complète avec score estimé et analyse détaillée par partie.
```

**Réponse attendue** : Test complet avec instructions de timing, correction détaillée, score estimé, et analyse partie par partie (pourcentage de réussite, points à travailler en priorité).

---

## CATÉGORIE 2 : ENTRAÎNEMENT LISTENING

### 2.1 Part 1 - Photographs (niveau B1-B2)

**Contexte d'usage** : Entraînement débutant/intermédiaire  
**Utilisateur** : Étudiant en autonomie  
**Timing** : Séances courtes (15-20 min)

**Prompt :**
```
Génère 10 exercices de type TOEIC Part 1 (Photographs) de niveau B1-B2. Pour chaque exercice, décris brièvement la photo imaginée, puis donne 4 descriptions possibles (A, B, C, D). Attends ma réponse, puis explique en français pourquoi une description est correcte et les autres sont incorrectes. Inclus du vocabulaire courant (personnes, objets, actions, lieux).
```

**Réponse attendue** : 10 exercices avec descriptions de photos réalistes, feedback en français après chaque réponse, focus sur les pièges courants (mots similaires, mauvaise interprétation visuelle).

---

### 2.2 Part 2 - Question-Response (niveau B2-C1)

**Contexte d'usage** : Entraînement intermédiaire/avancé  
**Utilisateur** : Étudiant en autonomie  
**Timing** : Séances courtes (20 min)

**Prompt :**
```
Génère 20 exercices TOEIC Part 2 (Question-Response) de niveau B2-C1. Pour chaque exercice, donne une question ou affirmation courte, suivie de 3 réponses possibles (A, B, C). Varie les types : questions Wh- (who, what, where, when, why, how), questions Yes/No, affirmations. Inclus des pièges classiques (répétition de mots, réponses hors contexte). Explique en français après chaque réponse.
```

**Réponse attendue** : 20 questions variées avec réponses plausibles et distracteurs efficaces, explications claires des pièges, conseils pour identifier rapidement la bonne réponse.

---

### 2.3 Part 3 - Conversations (niveau B1-C1)

**Contexte d'usage** : Entraînement compréhension dialogues  
**Utilisateur** : Étudiant ou classe  
**Timing** : Séances moyennes (30 min)

**Prompt :**
```
Génère 5 conversations TOEIC Part 3 (2-3 personnes) avec 3 questions chacune (total 15 questions). Varie les contextes : bureau, magasin, restaurant, aéroport, service client. Chaque conversation : 8-12 répliques, accents variés (américain, britannique, australien), questions sur les rôles des personnes, intentions, détails spécifiques, ou inférences. Fournis la transcription après mes réponses et explique en français.
```

**Réponse attendue** : 5 dialogues réalistes avec questions variées, transcription complète, feedback détaillé, identification des indices sonores et stratégies d'écoute.

---

### 2.4 Part 4 - Talks (niveau B2-C1)

**Contexte d'usage** : Entraînement monologues  
**Utilisateur** : Étudiant autonome  
**Timing** : Séances moyennes (30 min)

**Prompt :**
```
Génère 5 monologues TOEIC Part 4 avec 3 questions chacun (total 15 questions). Types de talks : annonces (aéroport, magasin), publicités, instructions (mode d'emploi, sécurité), extraits de réunion, messages vocaux. Durée imaginée : 30-45 secondes par talk. Questions sur le sujet principal, détails spécifiques, public cible, ou intentions du locuteur. Fournis la transcription et explique en français.
```

**Réponse attendue** : 5 monologues cohérents avec contexte professionnel, questions testant compréhension globale et détails, feedback avec techniques d'anticipation et prise de notes.

---

## CATÉGORIE 3 : ENTRAÎNEMENT READING

### 3.1 Part 5 - Incomplete Sentences (grammaire, niveau B1-B2)

**Contexte d'usage** : Renforcement grammatical de base  
**Utilisateur** : Étudiant avec lacunes grammaticales  
**Timing** : Séances courtes (20-30 min)

**Prompt :**
```
Génère 30 questions TOEIC Part 5 (Incomplete Sentences) de niveau B1-B2, focalisées sur la grammaire de base : temps verbaux (présent, passé, futur, present perfect), prépositions, comparatifs/superlatifs, modaux, voix passive. Pour chaque question, donne une phrase avec un blanc et 4 options (A, B, C, D). Explique en français la règle de grammaire après chaque réponse.
```

**Réponse attendue** : 30 phrases à compléter avec focus grammaire, explications claires des règles, exemples supplémentaires, conseils pour identifier rapidement le type d'erreur.

---

### 3.2 Part 5 - Incomplete Sentences (vocabulaire, niveau B2-C1)

**Contexte d'usage** : Enrichissement vocabulaire professionnel  
**Utilisateur** : Étudiant niveau intermédiaire/avancé  
**Timing** : Séances courtes (20-30 min)

**Prompt :**
```
Génère 30 questions TOEIC Part 5 (Incomplete Sentences) de niveau B2-C1, focalisées sur le vocabulaire professionnel : choix du mot approprié (synonymes, nuances de sens), collocations (mots qui vont ensemble), expressions idiomatiques business. Contextes variés : ressources humaines, finance, marketing, logistique, services. Explique en français les nuances de vocabulaire.
```

**Réponse attendue** : 30 phrases avec choix de vocabulaire subtils, explications des différences entre synonymes, exemples d'usage en contexte, listes de collocations fréquentes.

---

### 3.3 Part 6 - Text Completion (niveau B1-C1)

**Contexte d'usage** : Entraînement textes à trous en contexte  
**Utilisateur** : Tous niveaux  
**Timing** : Séances moyennes (30 min)

**Prompt :**
```
Génère 4 textes TOEIC Part 6 (Text Completion) avec 4 questions chacun (total 16 questions). Types de textes : emails professionnels, notices, articles courts, annonces. Chaque texte : 4 blancs à compléter (grammaire, vocabulaire, ou insertion de phrase complète). Adapte la difficulté à mon niveau [préciser B1/B2/C1]. Explique en français pourquoi chaque réponse est correcte dans le contexte du texte.
```

**Réponse attendue** : 4 textes cohérents avec blancs stratégiques, questions variées (grammaire, vocabulaire, cohérence textuelle), feedback expliquant l'importance du contexte pour choisir la bonne réponse.

---

### 3.4 Part 7 - Single Passages (niveau B1-B2)

**Contexte d'usage** : Entraînement lecture passages simples  
**Utilisateur** : Étudiant débutant/intermédiaire  
**Timing** : Séances moyennes (30-40 min)

**Prompt :**
```
Génère 5 passages simples TOEIC Part 7 avec 2-3 questions chacun (total 12-15 questions). Types de documents : emails, annonces, publicités, articles courts, notices. Longueur : 80-120 mots par passage. Questions sur : idée principale, détails spécifiques, inférences simples, vocabulaire en contexte. Niveau B1-B2. Explique en français les stratégies de lecture rapide.
```

**Réponse attendue** : 5 documents variés et réalistes, questions testant différentes compétences de lecture, feedback avec techniques de scanning et skimming, identification des mots-clés.

---

### 3.5 Part 7 - Multiple Passages (niveau B2-C1)

**Contexte d'usage** : Entraînement lecture passages multiples (double/triple)  
**Utilisateur** : Étudiant niveau avancé  
**Timing** : Séances longues (40-50 min)

**Prompt :**
```
Génère 3 sets de passages multiples TOEIC Part 7 : 1 set de 2 passages (5 questions) et 2 sets de 3 passages (5 questions chacun). Contextes : correspondance d'entreprise (email + réponse), offre d'emploi + CV + email, projet + budget + rapport. Longueur totale : 250-350 mots par set. Questions testant la compréhension croisée des documents. Niveau B2-C1. Explique en français comment gérer ces passages interconnectés.
```

**Réponse attendue** : 3 sets de documents interconnectés, questions nécessitant de croiser les informations, feedback sur la gestion du temps et la navigation entre documents, techniques pour identifier rapidement les liens.

---

## CATÉGORIE 4 : ENTRAÎNEMENT SPEAKING & WRITING (OPTIONNEL)

### 4.1 TOEIC Speaking - Question 1-2 (Read a text aloud)

**Contexte d'usage** : Préparation Speaking si demandé  
**Utilisateur** : Étudiant visant le test 4-Skills  
**Timing** : Séances courtes (15 min)

**Prompt :**
```
Génère 3 textes courts (40-50 mots) de type TOEIC Speaking Task 1-2 (Read aloud). Contextes : annonces, publicités, notices. Donne-moi des conseils en français pour améliorer ma prononciation, mon rythme, et mon intonation. Indique les pièges de prononciation courants (liaisons, mots difficiles).
```

**Réponse attendue** : 3 textes à lire à voix haute, conseils de prononciation détaillés, identification des mots difficiles, recommandations pour s'entraîner (enregistrement, réécoute).

---

### 4.2 TOEIC Speaking - Question 10-11 (Propose a solution)

**Contexte d'usage** : Préparation Speaking avancé  
**Utilisateur** : Étudiant niveau B2-C1  
**Timing** : Séances moyennes (20 min)

**Prompt :**
```
Génère 2 situations-problèmes de type TOEIC Speaking Task 10-11 (Propose a solution). Contextes professionnels : client mécontent, erreur de livraison, changement de planning. Donne-moi le scénario, puis évalue ma réponse (si je la donne) ou fournis un modèle de réponse en anglais avec explications en français des éléments clés d'une bonne réponse (structure, vocabulaire, ton).
```

**Réponse attendue** : 2 problèmes réalistes avec contexte détaillé, modèle de réponse structurée (introduction, solution, conclusion), feedback sur le vocabulaire de la résolution de problèmes, conseils de fluidité.

---

### 4.3 TOEIC Writing - Write a sentence based on a picture

**Contexte d'usage** : Préparation Writing de base  
**Utilisateur** : Étudiant Writing débutant  
**Timing** : Séances courtes (15 min)

**Prompt :**
```
Génère 5 descriptions de photos (comme dans TOEIC Writing Task 1-5) et demande-moi d'écrire une phrase grammaticalement correcte utilisant 2 mots clés imposés. Évalue mes phrases et donne-moi des corrections détaillées en français si nécessaire. Focus : grammaire, structure de phrase, vocabulaire précis.
```

**Réponse attendue** : 5 photos décrites avec mots-clés imposés, évaluation des phrases produites (grammaire, clarté, vocabulaire), suggestions d'amélioration, exemples de phrases modèles.

---

### 4.4 TOEIC Writing - Write an opinion essay

**Contexte d'usage** : Préparation Writing avancé  
**Utilisateur** : Étudiant niveau B2-C1  
**Timing** : Séance longue (40 min)

**Prompt :**
```
Génère 1 sujet de type TOEIC Writing Task 8 (Opinion essay, 300 mots, 30 minutes). Sujet controversé mais professionnel (ex : télétravail, formation continue, réseaux sociaux en entreprise). Donne-moi le sujet, puis évalue mon essai (si je le produis) ou fournis un modèle d'essai en anglais avec analyse en français de la structure, des arguments, et du vocabulaire utilisé.
```

**Réponse attendue** : 1 sujet stimulant, modèle d'essai bien structuré (introduction, 2-3 paragraphes d'arguments, conclusion), analyse détaillée de la structure argumentative, vocabulaire de l'opinion et de l'argumentation.

---

## CATÉGORIE 5 : PLANS DE RÉVISION PERSONNALISÉS

### 5.1 Plan de révision 2 semaines (intensif)

**Contexte d'usage** : Préparation de dernière minute  
**Utilisateur** : Étudiant avec examen imminent  
**Timing** : Planification globale

**Prompt :**
```
Je passe le TOEIC dans 2 semaines. Mon niveau actuel est [B1/B2/C1], mon score estimé est [XXX], je vise [YYY] points. Je peux consacrer [X heures] par jour à la préparation. Mes principales faiblesses sont [liste]. Crée-moi un plan de révision intensif de 2 semaines, jour par jour, avec répartition des parties à travailler, nombre d'exercices, et jalons de progression (mini-tests).
```

**Réponse attendue** : Plan détaillé sur 14 jours, répartition équilibrée Listening/Reading, focus sur les points faibles, 2-3 mini-tests inclus, conseils de gestion du stress et de récupération.

---

### 5.2 Plan de révision 4 semaines (standard)

**Contexte d'usage** : Préparation classique  
**Utilisateur** : Étudiant avec délai raisonnable  
**Timing** : Planification globale

**Prompt :**
```
Je passe le TOEIC dans 4 semaines. Mon niveau est [B1/B2/C1], score actuel [XXX], objectif [YYY]. Temps disponible : [X heures/semaine]. Points faibles : [liste]. Crée-moi un plan de révision de 4 semaines, semaine par semaine, avec progression graduelle (des exercices simples aux simulations complètes), répartition Listening/Reading, et 3-4 mini-tests inclus.
```

**Réponse attendue** : Plan structuré sur 4 semaines, montée en difficulté progressive, alternance entraînement ciblé et tests, conseils de régularité, ajustements possibles selon progression.

---

### 5.3 Plan de révision 8 semaines (optimal)

**Contexte d'usage** : Préparation confortable avec marge  
**Utilisateur** : Étudiant bien organisé  
**Timing** : Planification globale

**Prompt :**
```
J'ai 8 semaines pour préparer le TOEIC. Niveau actuel [B1/B2/C1], score [XXX], cible [YYY]. Disponibilité : [X heures/semaine]. Points faibles : [liste]. Crée-moi un plan de révision de 8 semaines avec :
- Semaines 1-2 : Diagnostic et renforcement des bases
- Semaines 3-5 : Entraînement intensif par parties
- Semaines 6-7 : Simulations et ajustements
- Semaine 8 : Révision finale et confiance
Inclus 5-6 mini-tests et 2 simulations complètes.
```

**Réponse attendue** : Plan détaillé sur 8 semaines avec phases clairement définies, progression pédagogique solide, révisions régulières, tests échelonnés, conseils de motivation sur la durée.

---

### 5.4 Plan de révision 12 semaines (formation longue durée)

**Contexte d'usage** : Cours semestriel ou formation diplômante  
**Utilisateur** : Professeur pour une classe  
**Timing** : Planification globale

**Prompt :**
```
Je suis enseignant et j'ai une classe de [XX] étudiants de niveau [B1/B2/C1] qui passent le TOEIC dans 12 semaines. Objectif moyen : [YYY] points. J'ai [X heures] de cours par semaine. Crée-moi un plan pédagogique de 12 semaines avec :
- Répartition des séances en classe (entraînement collectif, simulations)
- Travail autonome recommandé entre les séances (avec l'agent TOEIC Coach)
- 4-5 tests de progression
- Suivi individuel des étudiants
Intègre des phases de diagnostic, d'entraînement différencié, et de consolidation.
```

**Réponse attendue** : Plan pédagogique complet sur 12 semaines, articulation cours/autonomie, différenciation pédagogique selon niveaux, outils de suivi, conseils pour maintenir la motivation du groupe.

---

## CATÉGORIE 6 : ANALYSE D'ERREURS ET RECOMMANDATIONS

### 6.1 Analyse des erreurs récurrentes

**Contexte d'usage** : Après plusieurs tests ou séances  
**Utilisateur** : Étudiant ou professeur  
**Timing** : Mi-parcours ou après chaque test

**Prompt :**
```
Voici mes résultats aux 5 derniers exercices/tests TOEIC :
- Test 1 : [score, parties les plus faibles]
- Test 2 : [score, parties les plus faibles]
- Test 3 : [score, parties les plus faibles]
- Test 4 : [score, parties les plus faibles]
- Test 5 : [score, parties les plus faibles]

Identifie mes erreurs récurrentes et mes points faibles persistants. Donne-moi des recommandations précises pour les corriger (types d'exercices, ressources, techniques).
```

**Réponse attendue** : Analyse croisée des résultats, identification de patterns d'erreurs (ex : toujours faible en Part 5 grammaire, ou Part 7 passages multiples), recommandations d'entraînement ciblé, ressources complémentaires suggérées.

---

### 6.2 Feedback personnalisé après simulation complète

**Contexte d'usage** : Après un test complet (200 questions)  
**Utilisateur** : Étudiant  
**Timing** : Après chaque simulation

**Prompt :**
```
Je viens de passer une simulation TOEIC complète (200 questions). Voici mes résultats :
- Listening : [score estimé, détail par partie]
- Reading : [score estimé, détail par partie]
- Score total estimé : [XXX/990]
- Temps restant en Reading : [X minutes]

Analyse ma performance, identifie mes 3 priorités d'amélioration, et propose un plan d'action pour les 2 prochaines semaines avant le prochain test.
```

**Réponse attendue** : Analyse détaillée des résultats, comparaison avec les objectifs, identification des 3 axes prioritaires, plan d'action concret (nombre d'exercices par jour, parties à travailler), encouragements et prévision de progression.

---

### 6.3 Recommandations pour améliorer la gestion du temps

**Contexte d'usage** : Étudiant qui n'a pas le temps de finir le Reading  
**Utilisateur** : Étudiant  
**Timing** : Dès que le problème est identifié

**Prompt :**
```
J'ai du mal à finir la partie Reading dans les 75 minutes. Je termine souvent avec 10-15 questions non répondues. Mes temps moyens sont :
- Part 5 (30 questions) : [X minutes]
- Part 6 (16 questions) : [X minutes]
- Part 7 (54 questions) : [X minutes]

Donne-moi des stratégies concrètes pour améliorer ma gestion du temps, répartis les 75 minutes optimalement, et propose des exercices chronométrés pour m'entraîner.
```

**Réponse attendue** : Analyse des temps, répartition idéale recommandée (Part 5 : 10-12 min, Part 6 : 8-10 min, Part 7 : 50-55 min), techniques de lecture rapide (skimming, scanning), exercices chronométrés progressifs, conseils de priorisation (ne pas bloquer sur une question).

---

### 6.4 Recommandations pour améliorer le vocabulaire

**Contexte d'usage** : Étudiant faible en vocabulaire (Part 5, Part 7)  
**Utilisateur** : Étudiant  
**Timing** : Dès identification de la lacune

**Prompt :**
```
Mon principal problème est le vocabulaire professionnel. Je fais beaucoup d'erreurs en Part 5 (choix de mots) et je ne comprends pas certains textes en Part 7 (passages business). Mon niveau actuel est [B1/B2]. Crée-moi un programme de renforcement du vocabulaire TOEIC sur 4 semaines, avec listes thématiques, exercices, et techniques de mémorisation.
```

**Réponse attendue** : Programme de vocabulaire structuré (25-30 mots nouveaux par semaine), listes thématiques (RH, finance, marketing, logistique, voyages), exercices d'application (phrases à trous, synonymes, collocations), techniques de mémorisation (flashcards, répétition espacée, usage en contexte), ressources complémentaires.

---

## CATÉGORIE 7 : SIMULATIONS ET TESTS

### 7.1 Mini-test express (30 questions, 30 minutes)

**Contexte d'usage** : Évaluation rapide en cours ou à la maison  
**Utilisateur** : Étudiant ou classe  
**Timing** : Séance courte

**Prompt :**
```
Génère un mini-test TOEIC express de 30 questions en 30 minutes : 15 Listening (Parts 1-4) + 15 Reading (Parts 5-7). Présente toutes les questions, puis fournis la correction complète avec score estimé (sur 990) et analyse rapide des points forts/faibles.
```

**Réponse attendue** : Test rapide équilibré, correction détaillée, conversion en score estimé, feedback bref mais actionnable.

---

### 7.2 Test partiel (100 questions, 1h)

**Contexte d'usage** : Évaluation intermédiaire  
**Utilisateur** : Étudiant ou classe  
**Timing** : Séance moyenne

**Prompt :**
```
Génère un test TOEIC partiel de 100 questions en 1 heure : 50 Listening (répartition proportionnelle Parts 1-4) + 50 Reading (répartition proportionnelle Parts 5-7). Respecte les proportions officielles. Fournis la correction complète, le score estimé, et une analyse détaillée par partie.
```

**Réponse attendue** : Test équilibré respectant les proportions TOEIC, correction complète, score estimé précis, analyse partie par partie avec pourcentage de réussite et recommandations.

---

### 7.3 Simulation complète (200 questions, 2h)

**Contexte d'usage** : Test blanc en conditions réelles  
**Utilisateur** : Étudiant ou classe  
**Timing** : Séance longue ou à la maison

**Prompt :**
```
Génère une simulation TOEIC complète de 200 questions en 2 heures : 100 Listening (~45 min) + 100 Reading (75 min). Respecte scrupuleusement le format officiel (Part 1 : 6Q, Part 2 : 25Q, Part 3 : 39Q, Part 4 : 30Q, Part 5 : 30Q, Part 6 : 16Q, Part 7 : 54Q). Fournis les instructions de timing, puis la correction complète avec score estimé et rapport détaillé de performance.
```

**Réponse attendue** : Test complet en format officiel, instructions claires de timing, correction exhaustive, score estimé précis (Listening + Reading + Total), rapport de performance avec comparaison aux objectifs, recommandations pour les dernières semaines avant l'examen.

---

## CATÉGORIE 8 : STRATÉGIES D'EXAMEN

### 8.1 Stratégies générales pour maximiser le score

**Contexte d'usage** : Avant les dernières semaines de préparation  
**Utilisateur** : Étudiant  
**Timing** : 2-3 semaines avant l'examen

**Prompt :**
```
Je passe le TOEIC dans 3 semaines. Donne-moi les 10 stratégies essentielles pour maximiser mon score le jour J : gestion du temps, techniques de "guessing" intelligent, pièges à éviter, gestion du stress, préparation matérielle, etc. Explique chaque stratégie en français avec des exemples concrets.
```

**Réponse attendue** : Liste de 10 stratégies concrètes et actionnables, explications détaillées, exemples de situations d'examen, conseils pour les appliquer lors des dernières simulations.

---

### 8.2 Pièges courants par partie et comment les éviter

**Contexte d'usage** : Révision stratégique avant l'examen  
**Utilisateur** : Étudiant ou classe  
**Timing** : Dernière semaine de préparation

**Prompt :**
```
Liste les pièges les plus courants dans chaque partie du TOEIC (Parts 1-7) et explique comment les identifier et les éviter. Donne des exemples concrets pour chaque type de piège. Focus sur les erreurs que font fréquemment les étudiants de niveau [B1/B2/C1].
```

**Réponse attendue** : Liste structurée par partie, description de 3-5 pièges par partie, techniques pour les repérer, exemples de questions avec pièges annotés, conseils de vigilance.

---

## NOTES D'UTILISATION POUR LES ENSEIGNANTS

- **Personnalisation** : Adaptez les prompts selon le niveau réel de vos étudiants (précisez toujours B1, B2 ou C1).
- **Intégration pédagogique** : Utilisez les prompts en séance (collective) ou proposez-les en travail autonome (individuel).
- **Suivi** : Demandez aux étudiants de noter leurs scores et de les reporter dans le tableur de suivi.
- **Flexibilité** : Les prompts sont modulables. N'hésitez pas à ajuster le nombre de questions, la durée, ou le focus thématique.
- **Feedback** : L'agent donne du feedback en français. Complétez en classe avec des explications plus approfondies sur les points difficiles récurrents.

---

**Ce document constitue la base de travail complète avec l'agent TOEIC Coach. Bonne préparation !**
