# Kit Complet Agent TOEIC Coach – Index des Fichiers

Ce document récapitule l'ensemble des fichiers créés pour le kit "Agent TOEIC Coach" destiné aux écoles et centres de formation.

---

## 📦 CONTENU DU KIT

Le kit comprend **6 documents** au format Markdown (.md), prêts à être utilisés, personnalisés, ou convertis en d'autres formats (PDF, Word, etc.).

---

## 📄 FICHIER 1 : Description de l'agent TOEIC Coach

**Nom du fichier :** `description-agent-toeic.md`

**Contenu :**
- Rôle principal de l'agent
- Public cible (étudiants B1–C1 en écoles, universités, BTS, centres de formation)
- Objectifs pédagogiques (amélioration du score, autonomie, réduction du stress)
- Fonctions clés :
  - Diagnostic de niveau initial
  - Entraînement ciblé par parties (Listening Parts 1-4, Reading Parts 5-7)
  - Simulation de mini-examens et tests complets
  - Feedback détaillé en français
  - Plans de révision personnalisés (2, 4, 8, 12 semaines)
  - Suivi de la progression dans le temps
- Limites et précautions (pas de vrais sujets TOEIC, rôle complémentaire au professeur)
- **5 scénarios d'usage typiques** :
  1. Étudiante en école d'ingénieur visant 785 points (8 semaines)
  2. Étudiant BTS visant 600 points (12 semaines)
  3. Salarié en formation continue visant 750 points (4 semaines)
  4. Étudiant Master visant 850+ points (6 semaines, niveau C1)
  5. Classe de 25 étudiants en école de management (niveau hétérogène)

**Utilisation :** Document de référence pour comprendre l'agent, ses capacités, et ses applications. À distribuer aux enseignants et coordinateurs pédagogiques.

---

## 📄 FICHIER 2 : Bibliothèque de prompts TOEIC Coach

**Nom du fichier :** `bibliotheque-prompts-toeic.md`

**Contenu :**

### A) PROMPT SYSTÈME PRINCIPAL
- Prompt complet à configurer pour l'agent TOEIC Coach (rôle, format TOEIC, questionnaire initial obligatoire, adaptation au niveau B1-C1, ton et explications, limites)

### B) BIBLIOTHÈQUE DE 25+ PROMPTS D'USAGE organisés par catégories :

**Catégorie 1 : Diagnostic initial (3 prompts)**
- Questionnaire de présentation complet
- Mini-test de positionnement (30 questions)
- Test de positionnement complet (100 questions)

**Catégorie 2 : Entraînement Listening (4 prompts)**
- Part 1 – Photographs (niveau B1-B2)
- Part 2 – Question-Response (niveau B2-C1)
- Part 3 – Conversations (niveau B1-C1)
- Part 4 – Talks (niveau B2-C1)

**Catégorie 3 : Entraînement Reading (5 prompts)**
- Part 5 – Grammaire (niveau B1-B2)
- Part 5 – Vocabulaire (niveau B2-C1)
- Part 6 – Text Completion (niveau B1-C1)
- Part 7 – Single Passages (niveau B1-B2)
- Part 7 – Multiple Passages (niveau B2-C1)

**Catégorie 4 : Entraînement Speaking & Writing (4 prompts optionnels)**
- Speaking – Read aloud
- Speaking – Propose a solution
- Writing – Sentence based on picture
- Writing – Opinion essay

**Catégorie 5 : Plans de révision personnalisés (4 prompts)**
- Plan 2 semaines (intensif)
- Plan 4 semaines (standard)
- Plan 8 semaines (optimal)
- Plan 12 semaines (formation longue durée)

**Catégorie 6 : Analyse d'erreurs et recommandations (4 prompts)**
- Analyse des erreurs récurrentes
- Feedback après simulation complète
- Recommandations gestion du temps
- Recommandations amélioration vocabulaire

**Catégorie 7 : Simulations et tests (3 prompts)**
- Mini-test express (30 questions, 30 min)
- Test partiel (100 questions, 1h)
- Simulation complète (200 questions, 2h)

**Catégorie 8 : Stratégies d'examen (2 prompts)**
- Stratégies générales pour maximiser le score
- Pièges courants par partie et comment les éviter

**Utilisation :** Document de travail quotidien pour les enseignants et les étudiants. Copier-coller les prompts dans l'interface de l'agent selon les besoins.

---

## 📄 FICHIER 3 : Modèles de séances TOEIC (B1–C1)

**Nom du fichier :** `modeles-seances-toeic.md`

**Contenu :**

### 6 séances types prêtes à l'emploi (90 minutes chacune)

**Séance 1 : Diagnostic & Définition des Objectifs**
- Niveau : B1–C1 (tous niveaux)
- Objectif : Évaluer le niveau initial, identifier points forts/faibles, présenter l'agent
- Déroulé détaillé : 10 min intro + 40 min test de positionnement + 10 min correction + 15 min analyse collective + 10 min objectifs individuels + 5 min consignes

**Séance 2 : Part 5 – Grammaire et Vocabulaire**
- Niveau : B1–B2
- Objectif : Maîtriser Part 5 (temps verbaux, prépositions, vocabulaire courant)
- Déroulé détaillé : 10 min rappel théorique + 20 min exercices grammaire + 10 min mise en commun + 20 min exercices vocabulaire + 10 min mise en commun + 15 min mini-test + 5 min debrief

**Séance 3 : Part 6 – Textes à Compléter**
- Niveau : B1–B2
- Objectif : Maîtriser Part 6 (compréhension du contexte, cohérence textuelle)
- Déroulé détaillé : 15 min présentation Part 6 + 25 min exercice guidé + 15 min analyse collective + 20 min exercice autonome + 10 min mini-test + 5 min debrief

**Séance 4 : Part 7 – Compréhension Écrite (Passages Simples)**
- Niveau : B2–C1
- Objectif : Développer lecture rapide et compréhension de documents professionnels
- Déroulé détaillé : 10 min présentation + 25 min exercice guidé + 15 min analyse (scanning) + 20 min exercice autonome + 15 min mini-test + 5 min debrief

**Séance 5 : Listening (Parts 3-4 – Dialogues et Monologues)**
- Niveau : B1–C1
- Objectif : Améliorer compréhension orale, développer écoute active et prise de notes
- Déroulé détaillé : 10 min présentation + 20 min exercice Part 3 + 15 min analyse + 20 min exercice Part 4 + 15 min mini-test + 10 min debrief

**Séance 6 : Mini-Simulation d'Examen et Débrief**
- Niveau : B1–C1
- Objectif : Simuler examen TOEIC en conditions réelles, évaluer progression, préparer psychologiquement
- Déroulé détaillé : 5 min instructions + 25 min Listening (50 Q) + 38 min Reading (50 Q) + 5 min correction + 12 min debrief individuel + 5 min debrief collectif

**Pour chaque séance :**
- Niveau visé, objectif pédagogique, durée, matériel nécessaire
- Tableau détaillé du déroulé (timing, activité, description, rôle de l'agent, rôle du professeur)
- Livrables de la séance
- Conseils pédagogiques

**Utilisation :** Planification des cours, préparation des séances par les enseignants. Adapter selon le niveau et les contraintes horaires.

---

## 📄 FICHIER 4 : Checklists pour les profs TOEIC Coach

**Nom du fichier :** `checklists-profs-toeic.md`

**Contenu :**

### 3 checklists pratiques et imprimables

**Checklist 1 : Onboarding de l'agent TOEIC Coach**
- Définir les objectifs de la classe (score cible, date d'examen, niveau)
- Configuration de l'agent (accès, prompt système, comptes étudiants)
- Consignes à donner aux étudiants (présentation, démonstration, règles d'usage)
- Points à vérifier avant le lancement (matériel, tests de connexion, diagnostic initial)

**Checklist 2 : Suivi hebdomadaire de la préparation TOEIC**
- Vérifier l'utilisation de l'agent par les étudiants (actifs/inactifs, équilibre Listening/Reading)
- Analyser la progression de la classe (scores moyens, parties faibles, étudiants en difficulté)
- Actions à mener selon les signaux (stagnation, inactivité, incompréhension, progression rapide)

**Checklist 3 : Préparation finale "Avant Examen" (2-3 semaines avant)**
- Vérification du niveau de préparation (nombre de tests, score actuel vs cible, faiblesses identifiées)
- Stratégies d'examen maîtrisées (gestion du temps, guessing intelligent, stratégies par partie)
- Préparation matérielle et logistique (documents, consignes officielles, conseils physiques/mentaux)
- Validation des connaissances clés (vocabulaire, grammaire, connecteurs)
- Dernière simulation complète obligatoire + débriefing
- Actions finales (révision légère, gestion du stress, derniers conseils)

**Utilisation :** Imprimer et cocher les cases au fur et à mesure. Conserver dans le classeur de préparation TOEIC pour suivi structuré.

---

## 📄 FICHIER 5 : Spécification du Tableur "Suivi de Progression TOEIC"

**Nom du fichier :** `spec-tableur-suivi-toeic.md`

**Contenu :**

### Spécification complète d'un tableur Excel/Google Sheets avec 3 onglets

**Onglet 1 : Guide d'utilisation**
- Objectif du tableur (enregistrer scores, visualiser évolution, identifier points forts/faibles, suivre progression)
- Comment remplir les données (informations de base, résultats par partie, calculs automatiques)
- Comment interpréter les résultats (score estimé, pourcentages par partie, progression)
- Comment travailler avec l'agent (prompts à utiliser selon les points faibles identifiés)
- Fréquence de mise à jour recommandée

**Onglet 2 : Données étudiants**
- **52 colonnes détaillées** (A-AM) :
  - Informations de base (nom, prénom, groupe, niveau, scores initial/cible, date examen)
  - Résultats par partie (Parts 1-7 : total questions, bonnes réponses, pourcentage calculé)
  - Scores estimés (Listening, Reading, Total sur 990)
  - Progression (vs score initial, écart au score cible)
  - Points forts/faibles identifiés automatiquement
  - Recommandations de l'agent
- **Formules Excel/Sheets complètes** pour tous les calculs automatiques
- **Mise en forme conditionnelle** (couleurs selon performance : rouge/orange/vert)

**Onglet 3 : Tableau de bord**
- **Section 1 : KPIs principaux** (10 indicateurs)
  - Nombre d'étudiants, scores moyens (actuel/initial/progression/cible)
  - Nombre et % d'étudiants ayant atteint leur score cible
  - Répartition par tranches de score (550+, 785+, 850+)
- **Section 2 : Répartition des niveaux** (B1, B2, C1)
- **Section 3 : Scores moyens par partie** (Parts 1-7)
- **Section 4 : Identification de la partie la plus faible** + recommandation d'action
- **5 graphiques recommandés** :
  1. Histogramme des scores actuels
  2. Courbe d'évolution du score moyen de la classe
  3. Barres horizontales des scores par partie
  4. Camembert de répartition des niveaux
  5. Nuage de points (progression individuelle)

**Utilisation :** Créer le tableur Excel/Google Sheets selon cette spécification. Distribuer aux enseignants et étudiants dès la séance 1. Mise à jour hebdomadaire recommandée.

---

## 📄 FICHIER 6 : Dossier Marketing – Agent TOEIC Coach

**Nom du fichier :** `dossier-marketing-toeic.md`

**Contenu :**

### Document 1 : Fiche Produit "Agent TOEIC Coach" (2 pages)
- Problématique des établissements (scores insuffisants, hétérogénéité, charge enseignants, coûts)
- Solution : Agent TOEIC Coach (description, 6 fonctions clés)
- Bénéfices pour étudiants, enseignants, établissement (résultats, gain de temps, image)
- Format de la solution (accès agent, documentation, outils de suivi, support)
- Modèles d'utilisation (formation diplômante, stage intensif, révision libre)
- **Tarification indicative** (3 formules : Starter, Pro, Enterprise) avec tarifs par étudiant
- Contact et offre d'essai gratuit 1 mois

### Document 2 : Plan de Diaporama (14 diapositives pour présentation 10-15 min)
- Diapo 1 : Page de titre
- Diapo 2 : Le défi TOEIC (problématique chiffrée)
- Diapo 3 : La solution Agent TOEIC Coach (3 bénéfices principaux)
- Diapo 4 : Comment ça marche (4 étapes pour les étudiants)
- Diapo 5 : Les 6 fonctions clés
- Diapo 6 : Bénéfices pour les enseignants
- Diapo 7 : Bénéfices pour l'établissement (ROI)
- Diapo 8 : Format de la solution (kit complet)
- Diapo 9 : 3 modèles d'utilisation (tableau comparatif)
- Diapo 10 : Tarification (tableau 3 formules)
- Diapo 11 : Cas d'usage concret (témoignage/exemple)
- Diapo 12 : Pourquoi choisir l'agent TOEIC Coach (4 points différenciants)
- Diapo 13 : Les prochaines étapes (démo, essai, déploiement)
- Diapo 14 : Contact et questions (coordonnées, QR code)
- **Conseils pour la présentation orale** (timing, messages clés, ton)

### Document 3 : Script d'Email Professionnel
- **Email de prospection initial** (objet, problématique, solution, résultats, proposition de démo)
- **Email de relance** (si pas de réponse après 1 semaine)
- **Email de suivi post-démonstration** (envoi documents, prochaines étapes)

**Utilisation :** Documents prêts à l'emploi pour la commercialisation de l'agent TOEIC Coach auprès des établissements. Personnaliser avec logo, coordonnées réelles, et tarifs finaux.

---

## 📊 RÉCAPITULATIF DU KIT

| **#** | **Fichier** | **Type** | **Pages** | **Utilisation** |
|-------|-------------|----------|-----------|-----------------|
| 1 | `description-agent-toeic.md` | Documentation technique | 12 | Référence pour comprendre l'agent |
| 2 | `bibliotheque-prompts-toeic.md` | Prompts opérationnels | 18 | Travail quotidien avec l'agent |
| 3 | `modeles-seances-toeic.md` | Fiches pédagogiques | 15 | Planification et animation des cours |
| 4 | `checklists-profs-toeic.md` | Outils de pilotage | 8 | Suivi structuré de la formation |
| 5 | `spec-tableur-suivi-toeic.md` | Spécification technique | 12 | Création du tableur Excel/Sheets |
| 6 | `dossier-marketing-toeic.md` | Documents commerciaux | 10 | Vente de la solution aux établissements |

**TOTAL : 6 fichiers, ~75 pages de contenu structuré et opérationnel**

---

## 🚀 COMMENT UTILISER CE KIT

### Étape 1 : Préparation (avant le lancement)

1. **Lire le fichier 1** (Description de l'agent) pour comprendre le concept global
2. **Créer le tableur** selon le fichier 5 (Spécification du tableur)
3. **Configurer le prompt système** de l'agent avec le prompt du fichier 2 (Bibliothèque de prompts, section A)
4. **Préparer la séance 1** avec le fichier 3 (Modèles de séances) et la checklist 1 du fichier 4

### Étape 2 : Déploiement (semaine 1)

1. **Séance d'introduction** (90 min) : diagnostic initial, présentation de l'agent, définition des objectifs
2. **Distribution des documents** aux étudiants : fichier 2 (prompts), lien vers le tableur, consignes d'usage
3. **Test de connexion** : tous les étudiants se connectent et génèrent un premier exercice

### Étape 3 : Déroulement (semaines 2-12)

1. **Suivre les séances types** du fichier 3 (Modèles de séances) selon la progression
2. **Utiliser les prompts** du fichier 2 pour générer des exercices adaptés
3. **Appliquer la checklist 2** du fichier 4 chaque semaine (suivi hebdomadaire)
4. **Mettre à jour le tableur** avec les scores des tests

### Étape 4 : Préparation finale (2-3 semaines avant l'examen)

1. **Appliquer la checklist 3** du fichier 4 (Avant Examen)
2. **Organiser une simulation complète** (séance 6 du fichier 3)
3. **Révisions ciblées** avec les prompts du fichier 2 (catégorie 6 : Analyse d'erreurs)

### Étape 5 : Commercialisation (pour vendre la solution)

1. **Utiliser le fichier 6** (Dossier Marketing) pour prospecter les établissements
2. **Envoyer l'email de prospection** aux responsables pédagogiques
3. **Préparer le diaporama** pour les présentations aux directions
4. **Proposer un essai gratuit** 1 mois (10 étudiants)

---

## 📞 SUPPORT ET PERSONNALISATION

Ce kit est conçu pour être **directement opérationnel**, mais vous pouvez le personnaliser selon vos besoins :

- **Adapter les niveaux** : si votre public est uniquement B1 ou uniquement C1, ajustez les séances et les prompts
- **Modifier les durées** : les séances sont calibrées pour 90 minutes, mais peuvent être étendues à 2h ou réduites à 60 min
- **Ajouter des prompts** : le fichier 2 contient 25+ prompts, mais vous pouvez en créer d'autres selon vos besoins spécifiques
- **Traduire en anglais** : si vous travaillez dans un contexte international, traduisez les documents (le contenu des exercices TOEIC reste en anglais)
- **Personnaliser le branding** : ajoutez votre logo, vos couleurs, vos coordonnées dans le dossier marketing

---

## ✅ CHECKLIST DE VÉRIFICATION DU KIT

Avant de déployer le kit TOEIC Coach, vérifiez que vous avez bien :

☐ **Téléchargé les 6 fichiers Markdown** (.md)  
☐ **Créé le tableur Excel/Google Sheets** selon le fichier 5  
☐ **Configuré le prompt système de l'agent** avec le fichier 2 (section A)  
☐ **Testé l'agent** avec quelques prompts du fichier 2 pour vérifier la qualité des réponses  
☐ **Préparé la séance 1** avec le fichier 3 et la checklist 1 du fichier 4  
☐ **Distribué les accès** à l'agent à tous les étudiants  
☐ **Formé les enseignants** à l'utilisation du kit (2h recommandées)  

**Si tous les points sont cochés → vous êtes prêt à démarrer la préparation TOEIC avec l'agent TOEIC Coach !** 🚀

---

**Bon déploiement et excellente préparation TOEIC à vos étudiants !**
