# Spécification du Tableur "Suivi de Progression TOEIC"

Ce document décrit la structure complète d'un tableur Excel/Google Sheets pour suivre la progression des étudiants dans leur préparation TOEIC avec l'agent TOEIC Coach.

Le tableur comprend **3 onglets** : Guide d'utilisation, Données étudiants, et Tableau de bord.

---

## ONGLET 1 : Guide d'utilisation

### Objectif de cet onglet

Expliquer aux professeurs et aux étudiants comment utiliser le tableur, comment remplir les données, et comment interpréter les résultats.

### Structure de l'onglet "Guide d'utilisation"

**Cellules A1-F20 : Texte explicatif**

```
┌────────────────────────────────────────────────────────────────────────────────┐
│ GUIDE D'UTILISATION - Tableur de Suivi de Progression TOEIC                   │
├────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│ 1. OBJECTIF DU TABLEUR                                                         │
│                                                                                 │
│ Ce tableur permet de suivre la progression de chaque étudiant dans sa          │
│ préparation au TOEIC Listening & Reading (200 questions, score 10-990).        │
│                                                                                 │
│ Il vous aide à :                                                                │
│  • Enregistrer les scores des tests et mini-tests passés via l'agent TOEIC     │
│  • Visualiser l'évolution du score estimé dans le temps                        │
│  • Identifier les points forts et faibles par partie (Parts 1-7)               │
│  • Suivre la progression globale de la classe                                  │
│  • Ajuster les plans de révision selon les résultats                           │
│                                                                                 │
│ ─────────────────────────────────────────────────────────────────────────────  │
│                                                                                 │
│ 2. COMMENT REMPLIR LES DONNÉES                                                 │
│                                                                                 │
│ ÉTAPE 1 : Aller dans l'onglet "Données étudiants"                              │
│                                                                                 │
│ ÉTAPE 2 : Remplir les informations de base pour chaque étudiant (lignes 2+) : │
│  • Nom, Prénom, Groupe                                                          │
│  • Niveau initial estimé (B1, B2, C1)                                           │
│  • Score initial estimé (résultat du test de positionnement, semaine 1)        │
│  • Score cible (objectif à atteindre)                                           │
│  • Date d'examen officiel                                                       │
│                                                                                 │
│ ÉTAPE 3 : Après chaque mini-test ou test complet, remplir les colonnes :      │
│  • Date du test                                                                 │
│  • Nombre de questions par partie (Part 1 à 7)                                 │
│  • Nombre de bonnes réponses par partie                                         │
│  • Points forts identifiés                                                      │
│  • Points faibles identifiés                                                    │
│                                                                                 │
│ ÉTAPE 4 : Le tableur calcule automatiquement :                                 │
│  • Le pourcentage de réussite par partie                                        │
│  • Le score TOEIC estimé (Listening + Reading)                                 │
│  • La progression depuis le score initial                                       │
│                                                                                 │
│ ─────────────────────────────────────────────────────────────────────────────  │
│                                                                                 │
│ 3. COMMENT INTERPRÉTER LES RÉSULTATS                                           │
│                                                                                 │
│ SCORE TOEIC ESTIMÉ :                                                            │
│  • Le score est calculé en fonction du nombre de bonnes réponses               │
│  • Formule simplifiée : (Bonnes réponses Listening / 100) × 495 +              │
│                         (Bonnes réponses Reading / 100) × 495                  │
│  • Score total = Listening + Reading (maximum 990)                             │
│                                                                                 │
│ POURCENTAGE DE RÉUSSITE PAR PARTIE :                                           │
│  • Moins de 50% : Faiblesse majeure → priorité absolue à travailler            │
│  • 50-70% : Amélioration nécessaire → entraînement ciblé régulier              │
│  • 70-85% : Bon niveau → consolidation et maintien                             │
│  • Plus de 85% : Très bon niveau → passer à la partie suivante                 │
│                                                                                 │
│ PROGRESSION :                                                                   │
│  • Comparez le score estimé actuel avec le score initial                       │
│  • Progression positive (+20, +50, +100 points) : continuez ainsi !            │
│  • Stagnation (0 à +10 points depuis 2 semaines) : ajuster le plan             │
│  • Régression (-10 points ou plus) : identifier la cause (fatigue, stress,     │
│    manque de régularité) et adapter                                             │
│                                                                                 │
│ ─────────────────────────────────────────────────────────────────────────────  │
│                                                                                 │
│ 4. COMMENT TRAVAILLER AVEC L'AGENT TOEIC COACH                                 │
│                                                                                 │
│ Après avoir identifié vos points faibles dans le tableur :                     │
│                                                                                 │
│ SI FAIBLE EN PART 5 (grammaire/vocabulaire) :                                  │
│  → Demandez à l'agent : "Génère 20 questions Part 5 niveau [B1/B2/C1]          │
│    focalisées sur [temps verbaux / prépositions / vocabulaire business]"       │
│                                                                                 │
│ SI FAIBLE EN PART 7 (lecture) :                                                │
│  → Demandez à l'agent : "Génère 3 passages Part 7 niveau [B1/B2/C1] avec      │
│    questions sur l'idée principale et les détails spécifiques"                 │
│                                                                                 │
│ SI FAIBLE EN LISTENING (Parts 1-4) :                                           │
│  → Demandez à l'agent : "Génère 5 dialogues Part 3 niveau [B1/B2/C1] avec     │
│    transcription, je veux travailler la compréhension orale"                   │
│                                                                                 │
│ CONSEIL : Travaillez vos points faibles en priorité, mais n'oubliez pas de    │
│ maintenir vos points forts (1-2 exercices par semaine sur les parties          │
│ déjà maîtrisées).                                                               │
│                                                                                 │
│ ─────────────────────────────────────────────────────────────────────────────  │
│                                                                                 │
│ 5. FRÉQUENCE DE MISE À JOUR                                                     │
│                                                                                 │
│  • Après chaque mini-test (recommandé : 1 à 2 fois par semaine)                │
│  • Après chaque test complet (recommandé : 1 fois toutes les 2 semaines)       │
│  • Minimum : mise à jour hebdomadaire pour suivre la progression               │
│                                                                                 │
│ ─────────────────────────────────────────────────────────────────────────────  │
│                                                                                 │
│ 6. CONTACT ET SUPPORT                                                           │
│                                                                                 │
│ En cas de difficulté technique ou pédagogique :                                │
│  • Contactez votre professeur d'anglais                                         │
│  • Consultez le document "Bibliothèque de prompts TOEIC Coach"                 │
│  • Utilisez l'agent TOEIC Coach pour obtenir des recommandations personnalisées│
│                                                                                 │
└────────────────────────────────────────────────────────────────────────────────┘
```

---

## ONGLET 2 : Données étudiants

### Objectif de cet onglet

Enregistrer les données individuelles de chaque étudiant : informations de base, résultats des tests par partie, scores estimés, et recommandations.

### Structure des colonnes (lignes 1 = en-têtes)

| **Col** | **Nom de colonne** | **Description** | **Type de données** | **Formule si applicable** |
|---------|-------------------|-----------------|---------------------|---------------------------|
| **A** | Nom | Nom de famille de l'étudiant | Texte | (saisie manuelle) |
| **B** | Prénom | Prénom de l'étudiant | Texte | (saisie manuelle) |
| **C** | Groupe | Groupe ou classe (ex : Groupe A, BUT3, Master 1) | Texte | (saisie manuelle) |
| **D** | Niveau initial | Niveau CECRL estimé au départ (B1, B2, C1) | Liste déroulante : B1, B2, C1 | (saisie manuelle) |
| **E** | Score initial | Score TOEIC estimé au test de positionnement (semaine 1) | Nombre (10-990) | (saisie manuelle) |
| **F** | Score cible | Score TOEIC objectif à atteindre | Nombre (10-990) | (saisie manuelle) |
| **G** | Date examen | Date de l'examen officiel TOEIC | Date (format JJ/MM/AAAA) | (saisie manuelle) |
| **H** | Date test | Date du dernier test passé | Date (format JJ/MM/AAAA) | (saisie manuelle) |
| **I** | Part 1 - Total Q | Nombre de questions Part 1 (max 6) | Nombre | (saisie manuelle) |
| **J** | Part 1 - Bonnes | Nombre de bonnes réponses Part 1 | Nombre | (saisie manuelle) |
| **K** | Part 1 - % | Pourcentage de réussite Part 1 | Pourcentage | `=SI(I2>0; J2/I2; 0)` |
| **L** | Part 2 - Total Q | Nombre de questions Part 2 (max 25) | Nombre | (saisie manuelle) |
| **M** | Part 2 - Bonnes | Nombre de bonnes réponses Part 2 | Nombre | (saisie manuelle) |
| **N** | Part 2 - % | Pourcentage de réussite Part 2 | Pourcentage | `=SI(L2>0; M2/L2; 0)` |
| **O** | Part 3 - Total Q | Nombre de questions Part 3 (max 39) | Nombre | (saisie manuelle) |
| **P** | Part 3 - Bonnes | Nombre de bonnes réponses Part 3 | Nombre | (saisie manuelle) |
| **Q** | Part 3 - % | Pourcentage de réussite Part 3 | Pourcentage | `=SI(O2>0; P2/O2; 0)` |
| **R** | Part 4 - Total Q | Nombre de questions Part 4 (max 30) | Nombre | (saisie manuelle) |
| **S** | Part 4 - Bonnes | Nombre de bonnes réponses Part 4 | Nombre | (saisie manuelle) |
| **T** | Part 4 - % | Pourcentage de réussite Part 4 | Pourcentage | `=SI(R2>0; S2/R2; 0)` |
| **U** | Part 5 - Total Q | Nombre de questions Part 5 (max 30) | Nombre | (saisie manuelle) |
| **V** | Part 5 - Bonnes | Nombre de bonnes réponses Part 5 | Nombre | (saisie manuelle) |
| **W** | Part 5 - % | Pourcentage de réussite Part 5 | Pourcentage | `=SI(U2>0; V2/U2; 0)` |
| **X** | Part 6 - Total Q | Nombre de questions Part 6 (max 16) | Nombre | (saisie manuelle) |
| **Y** | Part 6 - Bonnes | Nombre de bonnes réponses Part 6 | Nombre | (saisie manuelle) |
| **Z** | Part 6 - % | Pourcentage de réussite Part 6 | Pourcentage | `=SI(X2>0; Y2/X2; 0)` |
| **AA** | Part 7 - Total Q | Nombre de questions Part 7 (max 54) | Nombre | (saisie manuelle) |
| **AB** | Part 7 - Bonnes | Nombre de bonnes réponses Part 7 | Nombre | (saisie manuelle) |
| **AC** | Part 7 - % | Pourcentage de réussite Part 7 | Pourcentage | `=SI(AA2>0; AB2/AA2; 0)` |
| **AD** | Total Listening - Bonnes | Total bonnes réponses Listening (Parts 1-4) | Nombre | `=J2+M2+P2+S2` |
| **AE** | Total Reading - Bonnes | Total bonnes réponses Reading (Parts 5-7) | Nombre | `=V2+Y2+AB2` |
| **AF** | Score Listening estimé | Score Listening (0-495) | Nombre | `=ARRONDI((AD2/100)*495; 0)` |
| **AG** | Score Reading estimé | Score Reading (0-495) | Nombre | `=ARRONDI((AE2/100)*495; 0)` |
| **AH** | Score TOEIC Total estimé | Score TOEIC total (0-990) | Nombre | `=AF2+AG2` |
| **AI** | Progression (vs initial) | Différence entre score actuel et score initial | Nombre | `=AH2-E2` |
| **AJ** | Écart au score cible | Différence entre score actuel et score cible | Nombre | `=AH2-F2` |
| **AK** | Points forts | Parties où le score est > 70% | Texte | (saisie manuelle ou formule complexe) |
| **AL** | Points faibles | Parties où le score est < 70% | Texte | (saisie manuelle ou formule complexe) |
| **AM** | Recommandations agent | Recommandations de l'agent TOEIC Coach | Texte (200 caractères max) | (saisie manuelle après analyse) |

### Formules détaillées pour automatisation

**Formule pour identifier les points forts (colonne AK, ligne 2) :**

```excel
=SI(K2>0,7; "Part 1 (Photos) "; "") & SI(N2>0,7; "Part 2 (Q-R) "; "") & SI(Q2>0,7; "Part 3 (Conv) "; "") & SI(T2>0,7; "Part 4 (Talks) "; "") & SI(W2>0,7; "Part 5 (Gram) "; "") & SI(Z2>0,7; "Part 6 (Texte) "; "") & SI(AC2>0,7; "Part 7 (Lecture) "; "")
```

**Formule pour identifier les points faibles (colonne AL, ligne 2) :**

```excel
=SI(K2<0,7; "Part 1 (Photos) "; "") & SI(N2<0,7; "Part 2 (Q-R) "; "") & SI(Q2<0,7; "Part 3 (Conv) "; "") & SI(T2<0,7; "Part 4 (Talks) "; "") & SI(W2<0,7; "Part 5 (Gram) "; "") & SI(Z2<0,7; "Part 6 (Texte) "; "") & SI(AC2<0,7; "Part 7 (Lecture) "; "")
```

### Mise en forme conditionnelle recommandée

**Pour les colonnes de pourcentage (K, N, Q, T, W, Z, AC) :**
- **Rouge** si < 50% (faiblesse majeure)
- **Orange** si 50-70% (amélioration nécessaire)
- **Vert clair** si 70-85% (bon niveau)
- **Vert foncé** si > 85% (très bon niveau)

**Pour la colonne "Progression" (AI) :**
- **Rouge** si < 0 (régression)
- **Orange** si 0 à +20 (stagnation/faible progression)
- **Vert clair** si +20 à +50 (bonne progression)
- **Vert foncé** si > +50 (excellente progression)

**Pour la colonne "Écart au score cible" (AJ) :**
- **Rouge** si < -50 (très loin de l'objectif)
- **Orange** si -50 à 0 (proche mais pas atteint)
- **Vert** si ≥ 0 (objectif atteint ou dépassé)

---

## ONGLET 3 : Tableau de bord

### Objectif de cet onglet

Fournir une vue synthétique de la progression de la classe entière, avec des KPIs (indicateurs clés) et des graphiques.

### Structure du tableau de bord

#### Section 1 : KPIs principaux (lignes 1-10)

| **Cellule** | **Indicateur** | **Formule** | **Format** |
|-------------|----------------|-------------|------------|
| **A1** | Nombre total d'étudiants | `=NBVAL('Données étudiants'!A2:A100)` | Nombre |
| **A2** | Score moyen de la classe (actuel) | `=MOYENNE('Données étudiants'!AH2:AH100)` | Nombre (0-990) |
| **A3** | Score moyen initial de la classe | `=MOYENNE('Données étudiants'!E2:E100)` | Nombre (0-990) |
| **A4** | Progression moyenne de la classe | `=A2-A3` | Nombre (+/- points) |
| **A5** | Score cible moyen de la classe | `=MOYENNE('Données étudiants'!F2:F100)` | Nombre (0-990) |
| **A6** | Nombre d'étudiants ayant atteint leur score cible | `=NB.SI('Données étudiants'!AJ2:AJ100; ">=0")` | Nombre |
| **A7** | Pourcentage d'étudiants ayant atteint leur score cible | `=A6/A1` | Pourcentage |
| **A8** | Nombre d'étudiants au-dessus de 550 points | `=NB.SI('Données étudiants'!AH2:AH100; ">=550")` | Nombre |
| **A9** | Nombre d'étudiants au-dessus de 785 points | `=NB.SI('Données étudiants'!AH2:AH100; ">=785")` | Nombre |
| **A10** | Nombre d'étudiants au-dessus de 850 points | `=NB.SI('Données étudiants'!AH2:AH100; ">=850")` | Nombre |

#### Section 2 : Répartition des niveaux (lignes 12-16)

| **Cellule** | **Indicateur** | **Formule** | **Format** |
|-------------|----------------|-------------|------------|
| **A12** | Nombre d'étudiants niveau B1 | `=NB.SI('Données étudiants'!D2:D100; "B1")` | Nombre |
| **A13** | Nombre d'étudiants niveau B2 | `=NB.SI('Données étudiants'!D2:D100; "B2")` | Nombre |
| **A14** | Nombre d'étudiants niveau C1 | `=NB.SI('Données étudiants'!D2:D100; "C1")` | Nombre |

#### Section 3 : Scores moyens par partie (lignes 18-25)

| **Cellule** | **Indicateur** | **Formule** | **Format** |
|-------------|----------------|-------------|------------|
| **A18** | Score moyen Part 1 (Photos) | `=MOYENNE('Données étudiants'!K2:K100)` | Pourcentage |
| **A19** | Score moyen Part 2 (Q-R) | `=MOYENNE('Données étudiants'!N2:N100)` | Pourcentage |
| **A20** | Score moyen Part 3 (Conversations) | `=MOYENNE('Données étudiants'!Q2:Q100)` | Pourcentage |
| **A21** | Score moyen Part 4 (Talks) | `=MOYENNE('Données étudiants'!T2:T100)` | Pourcentage |
| **A22** | Score moyen Part 5 (Grammaire) | `=MOYENNE('Données étudiants'!W2:W100)` | Pourcentage |
| **A23** | Score moyen Part 6 (Textes à trous) | `=MOYENNE('Données étudiants'!Z2:Z100)` | Pourcentage |
| **A24** | Score moyen Part 7 (Lecture) | `=MOYENNE('Données étudiants'!AC2:AC100)` | Pourcentage |

#### Section 4 : Identification des parties les plus faibles de la classe (lignes 27-30)

Utiliser la fonction `MIN()` pour identifier la partie avec le score moyen le plus faible, puis afficher une recommandation d'action.

| **Cellule** | **Indicateur** | **Formule** | **Format** |
|-------------|----------------|-------------|------------|
| **A27** | Partie la plus faible de la classe | (Formule complexe pour identifier la partie avec MIN(A18:A24)) | Texte (ex : "Part 5") |
| **A28** | Recommandation d'action | (Texte conditionnel selon la partie identifiée) | Texte (ex : "Organiser une séance ciblée sur la grammaire") |

### Graphiques recommandés

**Graphique 1 : Répartition des scores actuels de la classe (histogramme)**
- Axe X : Tranches de score (0-550, 550-650, 650-750, 750-850, 850-990)
- Axe Y : Nombre d'étudiants
- Source de données : colonne AH (Score TOEIC Total estimé) de l'onglet "Données étudiants"

**Graphique 2 : Évolution du score moyen de la classe (courbe)**
- Axe X : Semaines (semaine 1, semaine 2, etc.)
- Axe Y : Score moyen
- Source de données : scores moyens enregistrés chaque semaine (nécessite un historique)

**Graphique 3 : Scores moyens par partie (diagramme en barres horizontales)**
- Axe X : Pourcentage de réussite (0-100%)
- Axe Y : Parties (Part 1 à Part 7)
- Source de données : lignes 18-24 (scores moyens par partie)
- Coloration : rouge si < 50%, orange si 50-70%, vert si > 70%

**Graphique 4 : Répartition des niveaux (camembert)**
- Catégories : B1, B2, C1
- Valeurs : nombre d'étudiants par niveau
- Source de données : lignes 12-14

**Graphique 5 : Progression individuelle (nuage de points)**
- Axe X : Score initial
- Axe Y : Score actuel
- Chaque point = un étudiant
- Ligne diagonale (score initial = score actuel) pour visualiser qui progresse (au-dessus) ou régresse (en-dessous)

---

## NOTES TECHNIQUES POUR LA CRÉATION DU TABLEUR

### Logiciel recommandé

- **Google Sheets** (recommandé) : partage facile, collaboration en temps réel, accessibilité depuis n'importe quel appareil
- **Microsoft Excel** : version 2016 ou supérieure pour compatibilité des formules

### Protection des cellules

- **Protéger les cellules contenant des formules** (colonnes K, N, Q, T, W, Z, AC, AD-AJ) pour éviter les modifications accidentelles
- **Laisser modifiables** les cellules de saisie manuelle (A-J, L-M, O-P, R-S, U-V, X-Y, AA-AB, AK-AM)

### Validation des données

- **Colonne D (Niveau initial)** : Liste déroulante avec valeurs B1, B2, C1
- **Colonnes E, F (Scores)** : Validation de nombre entre 10 et 990
- **Colonnes I-AB (Nombre de questions/bonnes réponses)** : Validation de nombre ≥ 0, ≤ maximum de la partie

### Format conditionnel

Appliquer les règles de mise en forme conditionnelle décrites ci-dessus (couleurs selon performance).

### Copie du template

- **Créer une ligne modèle (ligne 2)** avec toutes les formules
- **Dupliquer cette ligne** pour chaque nouvel étudiant (jusqu'à 100 lignes recommandées)

---

## UTILISATION DU TABLEUR DANS LA PRATIQUE

### Scénario 1 : Remplissage après le test de positionnement (semaine 1)

1. Le professeur ouvre l'onglet "Données étudiants"
2. Pour chaque étudiant, il remplit : Nom, Prénom, Groupe, Niveau initial, Score initial (résultat du test de 30 questions généré par l'agent), Score cible, Date examen
3. Les colonnes I-AB restent vides (pas encore de test complet passé)
4. Le tableur affiche dans l'onglet "Tableau de bord" : score moyen initial de la classe, répartition des niveaux

### Scénario 2 : Remplissage après un mini-test (semaine 3)

1. L'étudiant passe un mini-test de 50 questions (25 Listening + 25 Reading) via l'agent
2. L'étudiant ou le professeur remplit dans l'onglet "Données étudiants" :
   - Date du test (colonne H)
   - Part 1 : 3 questions, 2 bonnes → colonnes I (3), J (2)
   - Part 2 : 12 questions, 8 bonnes → colonnes L (12), M (8)
   - Part 3 : 10 questions, 6 bonnes → colonnes O (10), P (6)
   - Part 5 : 15 questions, 10 bonnes → colonnes U (15), V (10)
   - Part 7 : 10 questions, 7 bonnes → colonnes AA (10), AB (7)
3. Le tableur calcule automatiquement :
   - Pourcentages par partie (colonnes K, N, Q, W, AC)
   - Score Listening estimé (33 bonnes / 100 × 495 ≈ 163)
   - Score Reading estimé (17 bonnes / 100 × 495 ≈ 84)
   - Score Total estimé : 163 + 84 = 247
   - Progression : 247 - score initial (ex : 247 - 450 = -203, régression anormale → vérifier les données)
4. L'étudiant consulte ses points faibles (colonne AL) : "Part 2 (Q-R) Part 3 (Conv) Part 5 (Gram)"
5. L'étudiant demande à l'agent TOEIC Coach des exercices ciblés sur ces parties

### Scénario 3 : Suivi hebdomadaire par le professeur

1. Le professeur ouvre l'onglet "Tableau de bord"
2. Il consulte les KPIs :
   - Score moyen de la classe : 650
   - Progression moyenne : +50 points (vs semaine 1)
   - 15 étudiants sur 25 ont atteint leur score cible
3. Il consulte le graphique "Scores moyens par partie" :
   - Part 5 (grammaire) est la plus faible (55% en moyenne)
4. Il décide d'organiser une séance ciblée sur Part 5 la semaine suivante (voir document "Modèles de séances TOEIC")

---

**Ce tableur constitue l'outil central de suivi de la préparation TOEIC. Créez-le soigneusement et formez les étudiants à son utilisation dès la première séance.**
